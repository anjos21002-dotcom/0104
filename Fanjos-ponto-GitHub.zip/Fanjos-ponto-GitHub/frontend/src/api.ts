import AsyncStorage from '@react-native-async-storage/async-storage';

const BASE = process.env.EXPO_PUBLIC_BACKEND_URL as string;

const TOKEN_KEY = 'pontocerto_token';

export async function getToken(): Promise<string | null> {
  return AsyncStorage.getItem(TOKEN_KEY);
}
export async function setToken(t: string) {
  await AsyncStorage.setItem(TOKEN_KEY, t);
}
export async function clearToken() {
  await AsyncStorage.removeItem(TOKEN_KEY);
}

async function authHeaders(): Promise<Record<string, string>> {
  const t = await getToken();
  return t ? { Authorization: `Bearer ${t}` } : {};
}

export type PunchType = 'entrada' | 'inicio_intervalo' | 'fim_intervalo' | 'saida';
export type Punch = {
  id: string;
  type: PunchType;
  photo_path: string;
  latitude: number;
  longitude: number;
  accuracy?: number | null;
  timestamp: string;
  within_geofence?: boolean | null;
  distance_m?: number | null;
};
export type Schedule = {
  start_time: string;
  interval_minutes: number;
  end_time: string;
};

export type TimeSheetDay = {
  date: string;
  is_workday: boolean;
  scheduled_minutes: number;
  worked_minutes: number;
  credited_minutes: number;
  bank_adjustment_minutes: number;
  balance_minutes: number;
  extra_minutes: number;
  negative_minutes: number;
  arrival_late_minutes: number;
  interval_excess_minutes: number;
  status: string;
  punches: { id: string; type: PunchType; timestamp: string; source: string }[];
  adjustments: { id: string; kind: string; minutes: number; note?: string | null }[];
};

export type TimeSheet = {
  user: { id: string; name: string; email: string };
  schedule: Schedule & { daily_minutes: number };
  rules: { late_tolerance_minutes: number; extra_tolerance_minutes: number };
  summary: { scheduled_minutes: number; worked_minutes: number; credited_minutes: number; extra_minutes: number; negative_minutes: number; balance_minutes: number };
  days: TimeSheetDay[];
};

async function req<T>(path: string, opts: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(await authHeaders()),
    ...((opts.headers as Record<string, string>) || {}),
  };
  const res = await fetch(`${BASE}/api${path}`, { ...opts, headers });
  if (!res.ok) {
    let msg = `Erro ${res.status}`;
    try {
      const j = await res.json();
      msg = j.detail || msg;
    } catch {}
    throw new Error(msg);
  }
  const ct = res.headers.get('content-type') || '';
  if (ct.includes('application/json')) return res.json();
  return (await res.text()) as unknown as T;
}

export const api = {
  BASE,
  async register(email: string, password: string, name: string) {
    return req<{ token: string; user: { id: string; email: string; name: string; role: string } }>(
      '/auth/register',
      { method: 'POST', body: JSON.stringify({ email, password, name }) }
    );
  },
  async login(email: string, password: string) {
    return req<{ token: string; user: { id: string; email: string; name: string; role: string } }>(
      '/auth/login',
      { method: 'POST', body: JSON.stringify({ email, password }) }
    );
  },
  async forgotPassword(email: string) {
    return req<{ ok: boolean; message: string }>('/auth/forgot-password', {
      method: 'POST', body: JSON.stringify({ email }),
    });
  },
  async me() {
    return req<{ id: string; email: string; name: string; role: string }>('/auth/me');
  },
  async getSchedule() {
    return req<Schedule>('/schedule');
  },
  async updateSchedule(s: Schedule) {
    return req<Schedule>('/schedule', { method: 'PUT', body: JSON.stringify(s) });
  },
  async uploadPhoto(uri: string): Promise<{ path: string }> {
    const token = await getToken();
    const form = new FormData();
    // Native shape
    form.append('file', { uri, name: `punch_${Date.now()}.jpg`, type: 'image/jpeg' } as any);
    const res = await fetch(`${BASE}/api/upload`, {
      method: 'POST',
      body: form,
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    if (!res.ok) {
      let msg = `Upload falhou (${res.status})`;
      try {
        const j = await res.json();
        msg = j.detail || msg;
      } catch {}
      throw new Error(msg);
    }
    return res.json();
  },
  async createPunch(p: {
    type: PunchType;
    photo_path: string;
    latitude: number;
    longitude: number;
    accuracy?: number;
  }) {
    return req<Punch>('/punches', { method: 'POST', body: JSON.stringify(p) });
  },
  async listPunches(start?: string, end?: string) {
    const q = new URLSearchParams();
    if (start) q.set('start', start);
    if (end) q.set('end', end);
    const s = q.toString();
    return req<Punch[]>(`/punches${s ? `?${s}` : ''}`);
  },
  async myTimeSheet(start: string, end: string) {
    return req<TimeSheet>(`/time-sheet?start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}`);
  },
  async exportHtmlUrl(start: string, end: string) {
    const token = await getToken();
    return `${BASE}/api/export/html?start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}&token=${token}`;
  },
  async fetchExportHtml(start: string, end: string): Promise<string> {
    const token = await getToken();
    const res = await fetch(
      `${BASE}/api/export/html?start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}`,
      { headers: token ? { Authorization: `Bearer ${token}` } : {} }
    );
    if (!res.ok) throw new Error('Falha ao gerar relatório');
    return res.text();
  },
  photoUrl(path: string, token: string | null) {
    return `${BASE}/api/files/${path}${token ? `?token=${token}` : ''}`;
  },

  // ---------- Admin ----------
  async adminListUsers() {
    return req<{ id: string; email: string; name: string; role: string }[]>('/admin/users');
  },
  async adminUpdateUser(userId: string, data: { name: string; email: string; role: 'user' | 'admin' }) {
    return req<{ id: string; email: string; name: string; role: string }>(`/admin/users/${userId}`, {
      method: 'PUT', body: JSON.stringify(data),
    });
  },
  async adminCreateUser(email: string, password: string, name: string, role: 'user' | 'admin' = 'user') {
    return req<{ id: string; email: string; name: string; role: string }>('/admin/users', {
      method: 'POST',
      body: JSON.stringify({ email, password, name, role }),
    });
  },
  async adminDeleteUser(userId: string) {
    return req<{ ok: boolean }>(`/admin/users/${userId}`, { method: 'DELETE' });
  },
  async adminResetPassword(userId: string, password: string) {
    return req<{ ok: boolean }>(`/admin/users/${userId}/reset-password`, {
      method: 'POST',
      body: JSON.stringify({ password }),
    });
  },
  async adminGetUserSchedule(userId: string) {
    return req<Schedule>(`/admin/users/${userId}/schedule`);
  },
  async adminUpdateUserSchedule(userId: string, s: Schedule) {
    return req<Schedule>(`/admin/users/${userId}/schedule`, {
      method: 'PUT',
      body: JSON.stringify(s),
    });
  },
  async adminListUserPunches(userId: string, start?: string, end?: string) {
    const q = new URLSearchParams();
    if (start) q.set('start', start);
    if (end) q.set('end', end);
    const s = q.toString();
    return req<Punch[]>(`/admin/users/${userId}/punches${s ? `?${s}` : ''}`);
  },
  async adminFetchExportHtml(userId: string, start: string, end: string): Promise<string> {
    const token = await getToken();
    const res = await fetch(
      `${BASE}/api/admin/users/${userId}/export/html?start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}`,
      { headers: token ? { Authorization: `Bearer ${token}` } : {} }
    );
    if (!res.ok) throw new Error('Falha ao gerar relatório');
    return res.text();
  },
  async adminUserTimeSheet(userId: string, start: string, end: string) {
    return req<TimeSheet>(`/admin/users/${userId}/time-sheet?start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}`);
  },
  async adminCreateManualPunch(userId: string, data: { type: PunchType; date: string; time: string }) {
    return req<Punch>(`/admin/users/${userId}/punches/manual`, { method: 'POST', body: JSON.stringify(data) });
  },
  async adminEditPunch(userId: string, punchId: string, data: { type: PunchType; date: string; time: string }) {
    return req<Punch>(`/admin/users/${userId}/punches/${punchId}`, { method: 'PUT', body: JSON.stringify(data) });
  },
  async adminDeletePunch(userId: string, punchId: string) {
    return req<{ ok: boolean }>(`/admin/users/${userId}/punches/${punchId}`, { method: 'DELETE' });
  },
  async adminListAdjustments(userId: string, start?: string, end?: string) {
    const q = new URLSearchParams();
    if (start) q.set('start', start);
    if (end) q.set('end', end);
    return req<{ id: string; user_id: string; date: string; kind: string; minutes: number; note?: string | null }[]>(`/admin/users/${userId}/adjustments${q.toString() ? `?${q.toString()}` : ''}`);
  },
  async adminCreateAdjustment(userId: string, data: { date: string; kind: 'atestado' | 'autorizado' | 'ferias' | 'abono_horas' | 'banco_horas'; minutes: number; note?: string }) {
    return req<{ id: string; date: string; kind: string; minutes: number; note?: string | null }>(`/admin/users/${userId}/adjustments`, { method: 'POST', body: JSON.stringify(data) });
  },
  async adminDeleteAdjustment(userId: string, adjustmentId: string) {
    return req<{ ok: boolean }>(`/admin/users/${userId}/adjustments/${adjustmentId}`, { method: 'DELETE' });
  },
  async adminListPasswordResetRequests() {
    return req<{ id: string; user_id: string; email: string; name: string; status: string; created_at: string }[]>('/admin/password-reset-requests');
  },
  async adminCompletePasswordResetRequest(requestId: string) {
    return req<{ ok: boolean }>(`/admin/password-reset-requests/${requestId}/complete`, { method: 'POST' });
  },
  async getWorkLocation() {
    return req<{ enabled: boolean; latitude?: number; longitude?: number; radius_m?: number; address?: string }>('/work-location');
  },
  async adminGetWorkLocation() {
    return req<{ enabled: boolean; latitude: number | null; longitude: number | null; radius_m: number; address: string | null }>('/admin/work-location');
  },
  async adminUpdateWorkLocation(v: { latitude: number | null; longitude: number | null; radius_m: number; address: string | null; enabled: boolean }) {
    return req<typeof v>('/admin/work-location', { method: 'PUT', body: JSON.stringify(v) });
  },
  async adminDashboard(start: string, end: string) {
    return req<{
      period: { start: string; end: string };
      workdays: string[];
      summary: {
        user_id: string; user_name: string; user_email: string; role: string;
        hours_worked: number; days_worked: number; days_missing: number; late_count: number;
        schedule: { start_time: string; interval_minutes: number; end_time: string };
      }[];
      alerts: { user_id: string; user_name: string; date: string; scheduled: string; actual: string | null; minutes_late: number | null; kind: 'late' | 'missing' }[];
      totals: { users: number; hours: number; late_events: number; missing_events: number };
    }>(`/admin/dashboard?start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}`);
  },
};
