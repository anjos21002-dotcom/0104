export const colors = {
  surface: '#F9F9F9',
  onSurface: '#111111',
  surfaceSecondary: '#FFFFFF',
  onSurfaceSecondary: '#444444',
  surfaceTertiary: '#F0F0F5',
  onSurfaceTertiary: '#666666',
  brand: '#2D6A4F',
  brandDark: '#1B4332',
  brandLight: '#D8F3DC',
  onBrand: '#FFFFFF',
  warning: '#FFB703',
  error: '#D90429',
  border: '#E5E5EA',
  borderStrong: '#C7C7CC',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
};

export const radius = {
  sm: 6,
  md: 12,
  lg: 20,
  pill: 999,
};
