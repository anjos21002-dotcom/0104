import { Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { colors, spacing, radius } from '@/src/theme';

export default function CeoFooter({ compact = false }: { compact?: boolean }) {
  const call = () => Linking.openURL('tel:+5581999758443');
  const whats = () => Linking.openURL('https://wa.me/5581999758443');

  return (
    <View style={[styles.wrap, compact && styles.wrapCompact]} testID="ceo-footer">
      <View style={styles.badge}>
        <Feather name="briefcase" size={14} color={colors.brand} />
        <Text style={styles.badgeText}>CEO</Text>
      </View>
      <Text style={styles.name}>Filipe Anjos</Text>
      <Text style={styles.hire}>Para contratar, entre em contato:</Text>
      <View style={styles.actions}>
        <Pressable testID="ceo-call" onPress={call} style={({ pressed }) => [styles.btn, pressed && { opacity: 0.85 }]}>
          <Feather name="phone" size={14} color={colors.onBrand} />
          <Text style={styles.btnText}>(81) 99975-8443</Text>
        </Pressable>
        <Pressable testID="ceo-whatsapp" onPress={whats} style={({ pressed }) => [styles.btnSecondary, pressed && { opacity: 0.85 }]}>
          <Feather name="message-circle" size={14} color={colors.brand} />
          <Text style={styles.btnSecondaryText}>WhatsApp</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    alignItems: 'center', paddingVertical: spacing.lg, paddingHorizontal: spacing.lg,
    backgroundColor: colors.surfaceSecondary, borderRadius: radius.lg,
    borderWidth: 1, borderColor: colors.border, gap: 6,
  },
  wrapCompact: { paddingVertical: spacing.md },
  badge: {
    flexDirection: 'row', gap: 4, alignItems: 'center',
    backgroundColor: colors.brandLight, paddingHorizontal: 8, paddingVertical: 3, borderRadius: radius.pill,
  },
  badgeText: { color: colors.brandDark, fontSize: 10, fontWeight: '500', letterSpacing: 0.5 },
  name: { fontSize: 16, fontWeight: '500', color: colors.onSurface, marginTop: 2 },
  hire: { fontSize: 12, color: colors.onSurfaceTertiary, marginBottom: spacing.sm },
  actions: { flexDirection: 'row', gap: spacing.sm, marginTop: 2 },
  btn: {
    backgroundColor: colors.brand, borderRadius: radius.pill, paddingHorizontal: spacing.md, paddingVertical: 8,
    flexDirection: 'row', alignItems: 'center', gap: 6,
  },
  btnText: { color: colors.onBrand, fontSize: 13, fontWeight: '500' },
  btnSecondary: {
    borderWidth: 1, borderColor: colors.brand, borderRadius: radius.pill, paddingHorizontal: spacing.md, paddingVertical: 8,
    flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: colors.surfaceSecondary,
  },
  btnSecondaryText: { color: colors.brand, fontSize: 13, fontWeight: '500' },
});
