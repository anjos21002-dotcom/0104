import { useState } from 'react';
import {
  View, Text, TextInput, Pressable, StyleSheet, KeyboardAvoidingView, Platform, ActivityIndicator, ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { api, setToken } from '@/src/api';
import { colors, spacing, radius } from '@/src/theme';

export default function Register() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async () => {
    setError(null);
    if (!name || !email || !password) {
      setError('Preencha todos os campos');
      return;
    }
    if (password.length < 6) {
      setError('Senha precisa ter ao menos 6 caracteres');
      return;
    }
    setLoading(true);
    try {
      const res = await api.register(email.trim(), password, name.trim());
      await setToken(res.token);
      router.replace('/(tabs)');
    } catch (e: any) {
      setError(e.message || 'Erro ao cadastrar');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container} testID="register-screen">
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps="handled">
          <View style={styles.headerRow}>
            <Pressable onPress={() => router.back()} testID="register-back-button" style={styles.backBtn}>
              <Feather name="chevron-left" size={24} color={colors.onSurface} />
            </Pressable>
            <Text style={styles.title}>Criar conta</Text>
            <View style={{ width: 32 }} />
          </View>

          <View style={styles.form}>
            <Text style={styles.label}>Nome</Text>
            <TextInput
              testID="register-name-input"
              style={styles.input}
              value={name}
              onChangeText={setName}
              placeholder="Seu nome"
              placeholderTextColor="#999"
            />
            <Text style={styles.label}>E-mail</Text>
            <TextInput
              testID="register-email-input"
              style={styles.input}
              value={email}
              onChangeText={setEmail}
              placeholder="voce@exemplo.com"
              placeholderTextColor="#999"
              autoCapitalize="none"
              keyboardType="email-address"
            />
            <Text style={styles.label}>Senha</Text>
            <TextInput
              testID="register-password-input"
              style={styles.input}
              value={password}
              onChangeText={setPassword}
              placeholder="Mín. 6 caracteres"
              placeholderTextColor="#999"
              secureTextEntry
            />
            {error && <Text style={styles.error} testID="register-error">{error}</Text>}

            <Pressable
              testID="register-submit-button"
              style={({ pressed }) => [styles.cta, pressed && { opacity: 0.8 }]}
              onPress={submit}
              disabled={loading}
            >
              {loading ? <ActivityIndicator color={colors.onBrand} /> : <Text style={styles.ctaText}>Criar conta</Text>}
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.surface },
  headerRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
  },
  backBtn: { width: 32, height: 32, alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 18, fontWeight: '500', color: colors.onSurface },
  form: { paddingHorizontal: spacing.xl, gap: spacing.sm, paddingTop: spacing.lg },
  label: { fontSize: 13, color: colors.onSurfaceSecondary, marginTop: spacing.md, marginBottom: spacing.xs },
  input: {
    backgroundColor: colors.surfaceSecondary, borderRadius: radius.md, paddingHorizontal: spacing.lg,
    paddingVertical: 14, fontSize: 16, color: colors.onSurface, borderWidth: 1, borderColor: colors.border,
  },
  cta: { backgroundColor: colors.brand, borderRadius: radius.md, paddingVertical: 16, alignItems: 'center', marginTop: spacing.xl },
  ctaText: { color: colors.onBrand, fontSize: 16, fontWeight: '500' },
  error: { color: colors.error, fontSize: 13, marginTop: spacing.xs },
});
