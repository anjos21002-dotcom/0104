import { useState } from 'react';
import {
  View, Text, TextInput, Pressable, StyleSheet, KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Link, useRouter } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { api, setToken } from '@/src/api';
import { colors, spacing, radius } from '@/src/theme';
import CeoFooter from '@/src/components/CeoFooter';

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [forgotLoading, setForgotLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const submit = async () => {
    setError(null); setMessage(null);
    if (!email || !password) { setError('Preencha e-mail e senha'); return; }
    setLoading(true);
    try {
      const res = await api.login(email.trim(), password);
      await setToken(res.token);
      router.replace('/(tabs)');
    } catch (e: any) {
      setError(e.message || 'Erro ao entrar');
    } finally { setLoading(false); }
  };

  const forgotPassword = async () => {
    setError(null); setMessage(null);
    if (!email.trim()) { setError('Digite seu e-mail para solicitar a redefinição da senha.'); return; }
    setForgotLoading(true);
    try {
      const res = await api.forgotPassword(email.trim());
      setMessage(res.message);
    } catch (e: any) {
      setError(e.message || 'Não foi possível enviar a solicitação.');
    } finally { setForgotLoading(false); }
  };

  return (
    <SafeAreaView style={styles.container} testID="login-screen">
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <View style={styles.header}>
          <View style={styles.logoCircle}><Feather name="clock" size={36} color={colors.onBrand} /></View>
          <Text style={styles.title}>PontoCerto</Text>
          <Text style={styles.subtitle}>Registro de ponto simples e confiável</Text>
        </View>

        <View style={styles.form}>
          <Text style={styles.label}>E-mail</Text>
          <TextInput
            testID="login-email-input" style={styles.input} value={email} onChangeText={setEmail}
            placeholder="voce@exemplo.com" placeholderTextColor="#999" autoCapitalize="none" keyboardType="email-address"
          />

          <Text style={styles.label}>Senha</Text>
          <View style={styles.passwordWrap}>
            <TextInput
              testID="login-password-input" style={styles.passwordInput} value={password} onChangeText={setPassword}
              placeholder="••••••••" placeholderTextColor="#999" secureTextEntry={!showPassword}
            />
            <Pressable
              testID="toggle-password-visibility" style={styles.eyeBtn}
              onPress={() => setShowPassword((v) => !v)}
              accessibilityLabel={showPassword ? 'Ocultar senha' : 'Mostrar senha'}
            >
              <Feather name={showPassword ? 'eye-off' : 'eye'} size={20} color={colors.onSurfaceTertiary} />
            </Pressable>
          </View>

          <Pressable testID="forgot-password-button" onPress={forgotPassword} disabled={forgotLoading} style={styles.forgotBtn}>
            {forgotLoading ? <ActivityIndicator size="small" color={colors.brand} /> : <Text style={styles.forgotText}>Esqueci minha senha</Text>}
          </Pressable>

          {error && <Text style={styles.error} testID="login-error">{error}</Text>}
          {message && <Text style={styles.success} testID="login-message">{message}</Text>}

          <Pressable
            testID="login-submit-button" style={({ pressed }) => [styles.cta, pressed && { opacity: 0.8 }]}
            onPress={submit} disabled={loading}
          >
            {loading ? <ActivityIndicator color={colors.onBrand} /> : <Text style={styles.ctaText}>Entrar</Text>}
          </Pressable>

          <Link href="/register" asChild>
            <Pressable style={styles.linkBtn} testID="go-register-button"><Text style={styles.linkText}>Criar nova conta</Text></Pressable>
          </Link>
        </View>
        <View style={styles.footerWrap}><CeoFooter compact /></View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.surface },
  header: { alignItems: 'center', paddingTop: spacing.xxl, paddingBottom: spacing.xl },
  logoCircle: { width: 72, height: 72, borderRadius: 36, backgroundColor: colors.brand, alignItems: 'center', justifyContent: 'center', marginBottom: spacing.lg },
  title: { fontSize: 28, fontWeight: '500', color: colors.onSurface, marginBottom: spacing.xs },
  subtitle: { fontSize: 14, color: colors.onSurfaceTertiary, textAlign: 'center', paddingHorizontal: spacing.xl },
  form: { paddingHorizontal: spacing.xl, gap: spacing.sm, flex: 1 },
  label: { fontSize: 13, color: colors.onSurfaceSecondary, marginTop: spacing.md, marginBottom: spacing.xs },
  input: { backgroundColor: colors.surfaceSecondary, borderRadius: radius.md, paddingHorizontal: spacing.lg, paddingVertical: 14, fontSize: 16, color: colors.onSurface, borderWidth: 1, borderColor: colors.border },
  passwordWrap: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surfaceSecondary, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border },
  passwordInput: { flex: 1, paddingLeft: spacing.lg, paddingVertical: 14, fontSize: 16, color: colors.onSurface },
  eyeBtn: { width: 48, height: 48, alignItems: 'center', justifyContent: 'center' },
  forgotBtn: { alignSelf: 'flex-end', paddingVertical: 6, minHeight: 32, justifyContent: 'center' },
  forgotText: { color: colors.brand, fontSize: 13, fontWeight: '500' },
  cta: { backgroundColor: colors.brand, borderRadius: radius.md, paddingVertical: 16, alignItems: 'center', marginTop: spacing.lg },
  ctaText: { color: colors.onBrand, fontSize: 16, fontWeight: '500' },
  linkBtn: { alignItems: 'center', paddingVertical: spacing.md, marginTop: spacing.sm },
  linkText: { color: colors.brand, fontSize: 14, fontWeight: '500' },
  error: { color: colors.error, fontSize: 13, marginTop: spacing.xs },
  success: { color: colors.brandDark, fontSize: 13, marginTop: spacing.xs, backgroundColor: colors.brandLight, padding: spacing.sm, borderRadius: radius.sm },
  footerWrap: { paddingHorizontal: spacing.xl, paddingBottom: spacing.md },
});
