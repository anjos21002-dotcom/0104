import { useCallback, useState } from 'react';
import {
  View, Text, StyleSheet, Pressable, ScrollView, ActivityIndicator, RefreshControl, Modal,
  TextInput, KeyboardAvoidingView, Platform, Switch,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect, useRouter } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import * as Location from 'expo-location';
import { api } from '@/src/api';
import { colors, spacing, radius } from '@/src/theme';

type AdminUser = { id: string; email: string; name: string; role: string };
type DashboardData = Awaited<ReturnType<typeof api.adminDashboard>>;
type WorkLoc = Awaited<ReturnType<typeof api.adminGetWorkLocation>>;

function last7Range() {
  const now = new Date();
  const end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999).toISOString();
  const d = new Date(now); d.setDate(d.getDate() - 6); d.setHours(0, 0, 0, 0);
  return { start: d.toISOString(), end };
}

export default function AdminScreen() {
  const router = useRouter();
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [dashboard, setDashboard] = useState<DashboardData | null>(null);
  const [workLoc, setWorkLoc] = useState<WorkLoc | null>(null);
  const [resetRequests, setResetRequests] = useState<{ id: string; user_id: string; email: string; name: string; created_at: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [me, setMe] = useState<AdminUser | null>(null);

  // Modals
  const [showCreate, setShowCreate] = useState(false);
  const [showReset, setShowReset] = useState<AdminUser | null>(null);
  const [showDelete, setShowDelete] = useState<AdminUser | null>(null);
  const [showGeofence, setShowGeofence] = useState(false);
  const [showAlerts, setShowAlerts] = useState(false);

  // Create form
  const [cName, setCName] = useState(''); const [cEmail, setCEmail] = useState('');
  const [cPassword, setCPassword] = useState(''); const [cRole, setCRole] = useState<'user' | 'admin'>('user');
  const [cSaving, setCSaving] = useState(false); const [cError, setCError] = useState<string | null>(null);

  // Reset form
  const [rPassword, setRPassword] = useState('');
  const [rSaving, setRSaving] = useState(false); const [rError, setRError] = useState<string | null>(null);

  // Delete form
  const [dSaving, setDSaving] = useState(false);

  // Geofence form
  const [gLat, setGLat] = useState(''); const [gLng, setGLng] = useState('');
  const [gRadius, setGRadius] = useState('200'); const [gAddress, setGAddress] = useState('');
  const [gEnabled, setGEnabled] = useState(false);
  const [gSaving, setGSaving] = useState(false); const [gFetching, setGFetching] = useState(false);

  const load = useCallback(async () => {
    try {
      const { start, end } = last7Range();
      const [list, meRes, dash, wl, resets] = await Promise.all([
        api.adminListUsers(),
        api.me(),
        api.adminDashboard(start, end).catch(() => null),
        api.adminGetWorkLocation().catch(() => null),
        api.adminListPasswordResetRequests().catch(() => []),
      ]);
      setUsers(list);
      setMe(meRes as AdminUser);
      setDashboard(dash);
      setWorkLoc(wl);
      setResetRequests(resets);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const openGeofence = () => {
    setGLat(workLoc?.latitude != null ? String(workLoc.latitude) : '');
    setGLng(workLoc?.longitude != null ? String(workLoc.longitude) : '');
    setGRadius(String(workLoc?.radius_m ?? 200));
    setGAddress(workLoc?.address ?? '');
    setGEnabled(!!workLoc?.enabled);
    setShowGeofence(true);
  };

  const useMyLocation = async () => {
    setGFetching(true);
    try {
      const p = await Location.requestForegroundPermissionsAsync();
      if (!p.granted) { setGFetching(false); return; }
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      setGLat(loc.coords.latitude.toFixed(6));
      setGLng(loc.coords.longitude.toFixed(6));
    } catch {}
    setGFetching(false);
  };

  const saveGeofence = async () => {
    setGSaving(true);
    try {
      await api.adminUpdateWorkLocation({
        latitude: gLat ? parseFloat(gLat) : null,
        longitude: gLng ? parseFloat(gLng) : null,
        radius_m: parseInt(gRadius) || 200,
        address: gAddress || null,
        enabled: gEnabled,
      });
      setShowGeofence(false);
      load();
    } catch {}
    setGSaving(false);
  };

  const doCreate = async () => {
    setCError(null);
    if (!cName || !cEmail || !cPassword) { setCError('Preencha todos os campos'); return; }
    setCSaving(true);
    try {
      await api.adminCreateUser(cEmail.trim(), cPassword, cName.trim(), cRole);
      setShowCreate(false);
      setCName(''); setCEmail(''); setCPassword(''); setCRole('user');
      load();
    } catch (e: any) { setCError(e.message || 'Erro ao criar'); }
    setCSaving(false);
  };

  const doReset = async () => {
    if (!showReset) return;
    setRError(null);
    if (!rPassword || rPassword.length < 4) { setRError('Senha muito curta (mín. 4 caracteres)'); return; }
    setRSaving(true);
    try {
      await api.adminResetPassword(showReset.id, rPassword);
      const pending = resetRequests.filter((r) => r.user_id === showReset.id);
      await Promise.all(pending.map((r) => api.adminCompletePasswordResetRequest(r.id).catch(() => null)));
      setShowReset(null); setRPassword('');
      load();
    } catch (e: any) { setRError(e.message || 'Erro ao resetar'); }
    setRSaving(false);
  };

  const doDeleteConfirmed = async () => {
    if (!showDelete) return;
    setDSaving(true);
    try {
      await api.adminDeleteUser(showDelete.id);
      setShowDelete(null);
      load();
    } catch {}
    setDSaving(false);
  };

  const alertCount = (dashboard?.totals.late_events ?? 0) + (dashboard?.totals.missing_events ?? 0);

  return (
    <SafeAreaView style={styles.container} edges={['top']} testID="admin-screen">
      <View style={styles.header}>
        <Text style={styles.title}>Administração</Text>
        <Pressable
          testID="admin-create-user-button"
          style={({ pressed }) => [styles.addBtn, pressed && { opacity: 0.85 }]}
          onPress={() => setShowCreate(true)}
        >
          <Feather name="user-plus" size={16} color={colors.onBrand} />
          <Text style={styles.addBtnText}>Novo</Text>
        </Pressable>
      </View>

      {loading ? (
        <ActivityIndicator color={colors.brand} style={{ marginTop: 40 }} />
      ) : (
        <ScrollView
          contentContainerStyle={{ padding: spacing.lg, paddingBottom: 120 }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor={colors.brand} />}
        >
          {/* Weekly Dashboard */}
          {dashboard && (
            <>
              <Text style={styles.sectionTitle}>ÚLTIMOS 7 DIAS</Text>
              <View style={styles.statsRow}>
                <View style={styles.statCard} testID="stat-users">
                  <Feather name="users" size={18} color={colors.brand} />
                  <Text style={styles.statValue}>{dashboard.totals.users}</Text>
                  <Text style={styles.statLabel}>Funcionários</Text>
                </View>
                <View style={styles.statCard} testID="stat-hours">
                  <Feather name="clock" size={18} color={colors.brand} />
                  <Text style={styles.statValue}>{dashboard.totals.hours.toFixed(1)}h</Text>
                  <Text style={styles.statLabel}>Trabalhadas</Text>
                </View>
              </View>
              <View style={styles.statsRow}>
                <View style={[styles.statCard, dashboard.totals.late_events > 0 && styles.statCardAlert]} testID="stat-late">
                  <Feather name="alert-triangle" size={18} color={dashboard.totals.late_events > 0 ? colors.warning : colors.brand} />
                  <Text style={styles.statValue}>{dashboard.totals.late_events}</Text>
                  <Text style={styles.statLabel}>Atrasos</Text>
                </View>
                <View style={[styles.statCard, dashboard.totals.missing_events > 0 && styles.statCardError]} testID="stat-missing">
                  <Feather name="x-circle" size={18} color={dashboard.totals.missing_events > 0 ? colors.error : colors.brand} />
                  <Text style={styles.statValue}>{dashboard.totals.missing_events}</Text>
                  <Text style={styles.statLabel}>Faltas</Text>
                </View>
              </View>

              {alertCount > 0 && (
                <Pressable
                  testID="view-alerts-button"
                  onPress={() => setShowAlerts(true)}
                  style={({ pressed }) => [styles.alertsBanner, pressed && { opacity: 0.85 }]}
                >
                  <Feather name="bell" size={18} color={colors.onBrand} />
                  <Text style={styles.alertsText}>
                    {dashboard.alerts.length} alerta{dashboard.alerts.length !== 1 ? 's' : ''} recente{dashboard.alerts.length !== 1 ? 's' : ''}
                  </Text>
                  <Feather name="chevron-right" size={18} color={colors.onBrand} />
                </Pressable>
              )}

              {/* Per-user summary */}
              <Text style={[styles.sectionTitle, { marginTop: spacing.lg }]}>DESEMPENHO SEMANAL</Text>
              <View style={styles.summaryCard}>
                {dashboard.summary.slice(0, 8).map((s, idx) => (
                  <Pressable
                    key={s.user_id}
                    testID={`summary-row-${s.user_id}`}
                    onPress={() => router.push(`/admin-user/${s.user_id}`)}
                    style={[styles.summaryRow, idx < Math.min(dashboard.summary.length, 8) - 1 && styles.summaryDivider]}
                  >
                    <View style={{ flex: 1 }}>
                      <Text style={styles.summaryName}>{s.user_name}</Text>
                      <Text style={styles.summarySub}>
                        {s.hours_worked.toFixed(1)}h · {s.days_worked} dia{s.days_worked !== 1 ? 's' : ''}
                      </Text>
                    </View>
                    <View style={styles.summaryPills}>
                      {s.late_count > 0 && (
                        <View style={[styles.pill, { backgroundColor: '#FFF3CD' }]}>
                          <Text style={[styles.pillText, { color: '#8A5D00' }]}>{s.late_count}⏰</Text>
                        </View>
                      )}
                      {s.days_missing > 0 && (
                        <View style={[styles.pill, { backgroundColor: '#FDECEE' }]}>
                          <Text style={[styles.pillText, { color: colors.error }]}>{s.days_missing}✕</Text>
                        </View>
                      )}
                    </View>
                  </Pressable>
                ))}
              </View>
            </>
          )}

          {/* Geofence card */}
          <Text style={[styles.sectionTitle, { marginTop: spacing.lg }]}>LOCAL DE TRABALHO</Text>
          <Pressable
            testID="edit-geofence-button"
            onPress={openGeofence}
            style={({ pressed }) => [styles.geofenceCard, pressed && { opacity: 0.85 }]}
          >
            <View style={[styles.geofenceIcon, workLoc?.enabled && { backgroundColor: colors.brandLight }]}>
              <Feather name="map-pin" size={20} color={workLoc?.enabled ? colors.brandDark : colors.onSurfaceTertiary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.geofenceTitle}>
                {workLoc?.enabled ? 'Cerca virtual ativa' : 'Cerca virtual desativada'}
              </Text>
              <Text style={styles.geofenceSub}>
                {workLoc?.enabled && workLoc.latitude != null
                  ? `${workLoc.address || `${workLoc.latitude.toFixed(4)}, ${workLoc.longitude?.toFixed(4)}`} · raio ${workLoc.radius_m}m`
                  : 'Toque para configurar'}
              </Text>
            </View>
            <Feather name="chevron-right" size={20} color={colors.onSurfaceTertiary} />
          </Pressable>

          {resetRequests.length > 0 && (
            <>
              <Text style={[styles.sectionTitle, { marginTop: spacing.lg }]}>SOLICITAÇÕES DE SENHA ({resetRequests.length})</Text>
              {resetRequests.map((r) => {
                const target = users.find((u) => u.id === r.user_id);
                return (
                  <View key={r.id} style={styles.userCard}>
                    <View style={styles.userMain}>
                      <View style={styles.avatar}><Feather name="key" size={16} color={colors.onBrand} /></View>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.userName}>{r.name || target?.name || 'Usuário'}</Text>
                        <Text style={styles.userEmail}>{r.email}</Text>
                      </View>
                    </View>
                    {target && (
                      <Pressable style={[styles.actionBtn, { margin: spacing.sm }]} onPress={() => { setShowReset(target); setRPassword(''); setRError(null); }}>
                        <Feather name="key" size={14} color={colors.brand} />
                        <Text style={[styles.actionText, { color: colors.brand }]}>Redefinir senha</Text>
                      </Pressable>
                    )}
                  </View>
                );
              })}
            </>
          )}

          {/* Users list */}
          <Text style={[styles.sectionTitle, { marginTop: spacing.lg }]}>USUÁRIOS ({users.length})</Text>
          {users.map((u) => (
            <View key={u.id} style={styles.userCard} testID={`user-card-${u.id}`}>
              <Pressable onPress={() => router.push(`/admin-user/${u.id}`)} style={styles.userMain}>
                <View style={[styles.avatar, u.role === 'admin' && { backgroundColor: colors.brandDark }]}>
                  <Text style={styles.avatarText}>{u.name.charAt(0).toUpperCase()}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                    <Text style={styles.userName}>{u.name}</Text>
                    {u.role === 'admin' && (
                      <View style={styles.badge}><Text style={styles.badgeText}>ADMIN</Text></View>
                    )}
                  </View>
                  <Text style={styles.userEmail}>{u.email}</Text>
                </View>
                <Feather name="chevron-right" size={20} color={colors.onSurfaceTertiary} />
              </Pressable>
              <View style={styles.actionsRow}>
                <Pressable
                  testID={`edit-user-${u.id}`}
                  style={styles.actionBtn}
                  onPress={() => router.push(`/admin-user/${u.id}`)}
                >
                  <Feather name="edit-3" size={14} color={colors.brand} />
                  <Text style={[styles.actionText, { color: colors.brand }]}>Editar / Ponto</Text>
                </Pressable>
                <Pressable
                  testID={`reset-password-${u.id}`}
                  style={styles.actionBtn}
                  onPress={() => { setShowReset(u); setRPassword(''); setRError(null); }}
                >
                  <Feather name="key" size={14} color={colors.onSurfaceSecondary} />
                  <Text style={styles.actionText}>Senha</Text>
                </Pressable>
                {u.id !== me?.id && (
                  <Pressable
                    testID={`delete-user-${u.id}`}
                    style={[styles.actionBtn, { backgroundColor: '#FDECEE' }]}
                    onPress={() => setShowDelete(u)}
                  >
                    <Feather name="trash-2" size={14} color={colors.error} />
                    <Text style={[styles.actionText, { color: colors.error }]}>Excluir</Text>
                  </Pressable>
                )}
              </View>
            </View>
          ))}
        </ScrollView>
      )}

      {/* Create User Modal */}
      <Modal visible={showCreate} animationType="slide" transparent onRequestClose={() => setShowCreate(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.modalBackdrop}>
          <View style={styles.modalCard} testID="create-user-modal">
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Novo Usuário</Text>
              <Pressable onPress={() => setShowCreate(false)} testID="close-create-modal"><Feather name="x" size={22} color={colors.onSurface} /></Pressable>
            </View>
            <Text style={styles.mLabel}>Nome</Text>
            <TextInput testID="create-user-name" style={styles.mInput} value={cName} onChangeText={setCName} placeholder="Nome completo" placeholderTextColor="#999" />
            <Text style={styles.mLabel}>E-mail</Text>
            <TextInput testID="create-user-email" style={styles.mInput} value={cEmail} onChangeText={setCEmail} placeholder="email@exemplo.com" placeholderTextColor="#999" autoCapitalize="none" keyboardType="email-address" />
            <Text style={styles.mLabel}>Senha</Text>
            <TextInput testID="create-user-password" style={styles.mInput} value={cPassword} onChangeText={setCPassword} placeholder="Mín. 4 caracteres" placeholderTextColor="#999" secureTextEntry />
            <Text style={styles.mLabel}>Papel</Text>
            <View style={styles.roleRow}>
              {(['user', 'admin'] as const).map((r) => (
                <Pressable key={r} testID={`role-chip-${r}`} onPress={() => setCRole(r)} style={[styles.roleChip, cRole === r && styles.roleChipActive]}>
                  <Text style={[styles.roleText, cRole === r && styles.roleTextActive]}>{r === 'user' ? 'Funcionário' : 'Administrador'}</Text>
                </Pressable>
              ))}
            </View>
            {cError && <Text style={styles.errText} testID="create-user-error">{cError}</Text>}
            <Pressable testID="submit-create-user" style={[styles.submitBtn, cSaving && { opacity: 0.7 }]} disabled={cSaving} onPress={doCreate}>
              {cSaving ? <ActivityIndicator color={colors.onBrand} /> : <Text style={styles.submitText}>Criar Usuário</Text>}
            </Pressable>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* Reset Password Modal */}
      <Modal visible={!!showReset} animationType="slide" transparent onRequestClose={() => setShowReset(null)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.modalBackdrop}>
          <View style={styles.modalCard} testID="reset-password-modal">
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Redefinir Senha</Text>
              <Pressable onPress={() => setShowReset(null)} testID="close-reset-modal"><Feather name="x" size={22} color={colors.onSurface} /></Pressable>
            </View>
            <Text style={styles.mSub}>Para: {showReset?.name} · {showReset?.email}</Text>
            <Text style={styles.mLabel}>Nova senha</Text>
            <TextInput testID="reset-password-input" style={styles.mInput} value={rPassword} onChangeText={setRPassword} placeholder="Nova senha" placeholderTextColor="#999" secureTextEntry />
            {rError && <Text style={styles.errText} testID="reset-password-error">{rError}</Text>}
            <Pressable testID="submit-reset-password" style={[styles.submitBtn, rSaving && { opacity: 0.7 }]} disabled={rSaving} onPress={doReset}>
              {rSaving ? <ActivityIndicator color={colors.onBrand} /> : <Text style={styles.submitText}>Salvar Nova Senha</Text>}
            </Pressable>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal visible={!!showDelete} animationType="fade" transparent onRequestClose={() => setShowDelete(null)}>
        <View style={styles.modalBackdropCenter}>
          <View style={styles.confirmCard} testID="delete-confirm-modal">
            <View style={styles.confirmIcon}>
              <Feather name="alert-triangle" size={28} color={colors.error} />
            </View>
            <Text style={styles.confirmTitle}>Excluir usuário?</Text>
            <Text style={styles.confirmDesc}>
              Você está prestes a excluir{' '}
              <Text style={{ fontWeight: '500' }}>{showDelete?.name}</Text> e todo o histórico de pontos.
              Esta ação não pode ser desfeita.
            </Text>
            <View style={styles.confirmActions}>
              <Pressable
                testID="cancel-delete"
                style={styles.cancelBtn}
                onPress={() => setShowDelete(null)}
              >
                <Text style={styles.cancelText}>Cancelar</Text>
              </Pressable>
              <Pressable
                testID="confirm-delete"
                style={[styles.dangerBtn, dSaving && { opacity: 0.7 }]}
                disabled={dSaving}
                onPress={doDeleteConfirmed}
              >
                {dSaving ? <ActivityIndicator color={colors.onBrand} /> : <Text style={styles.dangerText}>Excluir</Text>}
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      {/* Geofence Modal */}
      <Modal visible={showGeofence} animationType="slide" transparent onRequestClose={() => setShowGeofence(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.modalBackdrop}>
          <View style={styles.modalCard} testID="geofence-modal">
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Local de Trabalho</Text>
              <Pressable onPress={() => setShowGeofence(false)} testID="close-geofence-modal"><Feather name="x" size={22} color={colors.onSurface} /></Pressable>
            </View>
            <View style={styles.switchRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.switchLabel}>Cerca virtual ativa</Text>
                <Text style={styles.switchSub}>Marca cada ponto como dentro ou fora do local</Text>
              </View>
              <Switch value={gEnabled} onValueChange={setGEnabled} trackColor={{ true: colors.brand }} testID="geofence-enabled-switch" />
            </View>
            <Text style={styles.mLabel}>Endereço (opcional)</Text>
            <TextInput testID="geofence-address" style={styles.mInput} value={gAddress} onChangeText={setGAddress} placeholder="Ex: Recife-PE" placeholderTextColor="#999" />
            <View style={{ flexDirection: 'row', gap: spacing.sm }}>
              <View style={{ flex: 1 }}>
                <Text style={styles.mLabel}>Latitude</Text>
                <TextInput testID="geofence-lat" style={styles.mInput} value={gLat} onChangeText={setGLat} placeholder="-8.05" placeholderTextColor="#999" keyboardType="numbers-and-punctuation" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.mLabel}>Longitude</Text>
                <TextInput testID="geofence-lng" style={styles.mInput} value={gLng} onChangeText={setGLng} placeholder="-34.9" placeholderTextColor="#999" keyboardType="numbers-and-punctuation" />
              </View>
            </View>
            <Pressable testID="use-my-location" onPress={useMyLocation} style={styles.useLocationBtn} disabled={gFetching}>
              {gFetching ? <ActivityIndicator color={colors.brand} /> : (
                <>
                  <Feather name="crosshair" size={14} color={colors.brand} />
                  <Text style={styles.useLocationText}>Usar minha localização atual</Text>
                </>
              )}
            </Pressable>
            <Text style={styles.mLabel}>Raio (metros)</Text>
            <TextInput testID="geofence-radius" style={styles.mInput} value={gRadius} onChangeText={setGRadius} placeholder="200" placeholderTextColor="#999" keyboardType="number-pad" />
            <Pressable testID="submit-geofence" style={[styles.submitBtn, gSaving && { opacity: 0.7 }]} disabled={gSaving} onPress={saveGeofence}>
              {gSaving ? <ActivityIndicator color={colors.onBrand} /> : <Text style={styles.submitText}>Salvar</Text>}
            </Pressable>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* Alerts Modal */}
      <Modal visible={showAlerts} animationType="slide" transparent onRequestClose={() => setShowAlerts(false)}>
        <View style={styles.modalBackdrop}>
          <View style={[styles.modalCard, { maxHeight: '85%' }]} testID="alerts-modal">
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Alertas de Atraso e Falta</Text>
              <Pressable onPress={() => setShowAlerts(false)} testID="close-alerts-modal"><Feather name="x" size={22} color={colors.onSurface} /></Pressable>
            </View>
            <Text style={styles.mSub}>Últimos 7 dias · Tolerância de 15 min</Text>
            <ScrollView style={{ maxHeight: 500 }}>
              {(dashboard?.alerts || []).map((a, idx) => (
                <Pressable
                  key={idx}
                  testID={`alert-row-${idx}`}
                  onPress={() => { setShowAlerts(false); router.push(`/admin-user/${a.user_id}`); }}
                  style={styles.alertRow}
                >
                  <View style={[styles.alertDot, { backgroundColor: a.kind === 'missing' ? colors.error : colors.warning }]} />
                  <View style={{ flex: 1 }}>
                    <Text style={styles.alertName}>{a.user_name}</Text>
                    <Text style={styles.alertMeta}>
                      {new Date(a.date).toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: 'short' })}
                      {' · previsto '}
                      {a.scheduled}
                      {a.kind === 'late' && a.actual ? ` · chegou ${a.actual}` : ''}
                    </Text>
                  </View>
                  {a.kind === 'late' ? (
                    <Text style={styles.alertBadgeWarn}>+{a.minutes_late}min</Text>
                  ) : (
                    <Text style={styles.alertBadgeErr}>FALTA</Text>
                  )}
                </Pressable>
              ))}
              {(!dashboard?.alerts || dashboard.alerts.length === 0) && (
                <Text style={{ textAlign: 'center', color: colors.onSurfaceTertiary, paddingVertical: spacing.xl }}>
                  Nenhum alerta 🎉
                </Text>
              )}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.surface },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingTop: spacing.md, paddingBottom: spacing.md,
  },
  title: { fontSize: 22, fontWeight: '500', color: colors.onSurface },
  addBtn: { backgroundColor: colors.brand, borderRadius: radius.pill, paddingHorizontal: spacing.md, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', gap: 6 },
  addBtnText: { color: colors.onBrand, fontSize: 13, fontWeight: '500' },
  sectionTitle: { fontSize: 12, color: colors.onSurfaceTertiary, textTransform: 'uppercase', letterSpacing: 0.6, marginBottom: spacing.sm },

  statsRow: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.sm },
  statCard: {
    flex: 1, backgroundColor: colors.surfaceSecondary, borderRadius: radius.md, padding: spacing.md,
    borderWidth: 1, borderColor: colors.border, gap: 4,
  },
  statCardAlert: { backgroundColor: '#FFFBEB', borderColor: '#FDE68A' },
  statCardError: { backgroundColor: '#FEF2F2', borderColor: '#FECACA' },
  statValue: { fontSize: 20, fontWeight: '500', color: colors.onSurface, marginTop: 2 },
  statLabel: { fontSize: 12, color: colors.onSurfaceTertiary },

  alertsBanner: {
    backgroundColor: colors.warning, borderRadius: radius.md, paddingHorizontal: spacing.lg,
    paddingVertical: 12, flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginTop: spacing.xs,
  },
  alertsText: { color: colors.onSurface, fontWeight: '500', fontSize: 14, flex: 1 },

  summaryCard: { backgroundColor: colors.surfaceSecondary, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, overflow: 'hidden' },
  summaryRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: spacing.md, paddingVertical: 12, gap: spacing.sm },
  summaryDivider: { borderBottomWidth: 1, borderBottomColor: colors.border },
  summaryName: { fontSize: 14, color: colors.onSurface, fontWeight: '500' },
  summarySub: { fontSize: 12, color: colors.onSurfaceTertiary, marginTop: 2 },
  summaryPills: { flexDirection: 'row', gap: 4 },
  pill: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: radius.sm },
  pillText: { fontSize: 11, fontWeight: '500' },

  geofenceCard: {
    backgroundColor: colors.surfaceSecondary, borderRadius: radius.md, padding: spacing.md,
    borderWidth: 1, borderColor: colors.border, flexDirection: 'row', alignItems: 'center', gap: spacing.md,
  },
  geofenceIcon: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: colors.surfaceTertiary,
    alignItems: 'center', justifyContent: 'center',
  },
  geofenceTitle: { fontSize: 14, color: colors.onSurface, fontWeight: '500' },
  geofenceSub: { fontSize: 12, color: colors.onSurfaceTertiary, marginTop: 2 },

  userCard: { backgroundColor: colors.surfaceSecondary, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, marginBottom: spacing.md, overflow: 'hidden' },
  userMain: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: spacing.lg, paddingVertical: spacing.md, gap: spacing.md },
  avatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.brand, alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: colors.onBrand, fontWeight: '500', fontSize: 16 },
  userName: { color: colors.onSurface, fontSize: 15, fontWeight: '500' },
  userEmail: { color: colors.onSurfaceTertiary, fontSize: 12, marginTop: 2 },
  badge: { backgroundColor: colors.brandLight, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },
  badgeText: { color: colors.brandDark, fontSize: 10, fontWeight: '500' },
  actionsRow: { flexDirection: 'row', gap: spacing.sm, paddingHorizontal: spacing.lg, paddingBottom: spacing.md },
  actionBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: spacing.md, paddingVertical: 8, backgroundColor: colors.surfaceTertiary, borderRadius: radius.sm },
  actionText: { color: colors.onSurfaceSecondary, fontSize: 12, fontWeight: '500' },

  modalBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end' },
  modalBackdropCenter: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', paddingHorizontal: spacing.xl },
  modalCard: { backgroundColor: colors.surfaceSecondary, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: spacing.xl, gap: spacing.xs },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: spacing.md },
  modalTitle: { fontSize: 18, fontWeight: '500', color: colors.onSurface },
  mSub: { fontSize: 13, color: colors.onSurfaceTertiary, marginBottom: spacing.md },
  mLabel: { fontSize: 13, color: colors.onSurfaceSecondary, marginTop: spacing.md, marginBottom: 4 },
  mInput: { backgroundColor: colors.surfaceTertiary, borderRadius: radius.md, paddingHorizontal: spacing.md, paddingVertical: 12, fontSize: 15, color: colors.onSurface, borderWidth: 1, borderColor: colors.border },
  roleRow: { flexDirection: 'row', gap: spacing.sm, marginTop: 4 },
  roleChip: { flex: 1, paddingVertical: 12, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surfaceTertiary, alignItems: 'center' },
  roleChipActive: { backgroundColor: colors.brand, borderColor: colors.brand },
  roleText: { color: colors.onSurfaceSecondary, fontSize: 13, fontWeight: '500' },
  roleTextActive: { color: colors.onBrand },
  submitBtn: { backgroundColor: colors.brand, borderRadius: radius.md, paddingVertical: 14, alignItems: 'center', marginTop: spacing.lg },
  submitText: { color: colors.onBrand, fontSize: 15, fontWeight: '500' },
  errText: { color: colors.error, fontSize: 13, marginTop: spacing.sm },

  confirmCard: { backgroundColor: colors.surfaceSecondary, borderRadius: radius.lg, padding: spacing.xl, alignItems: 'center', gap: spacing.sm },
  confirmIcon: { width: 56, height: 56, borderRadius: 28, backgroundColor: '#FDECEE', alignItems: 'center', justifyContent: 'center', marginBottom: spacing.sm },
  confirmTitle: { fontSize: 18, fontWeight: '500', color: colors.onSurface },
  confirmDesc: { fontSize: 14, color: colors.onSurfaceSecondary, textAlign: 'center', marginBottom: spacing.md, lineHeight: 20 },
  confirmActions: { flexDirection: 'row', gap: spacing.sm, width: '100%' },
  cancelBtn: { flex: 1, paddingVertical: 14, backgroundColor: colors.surfaceTertiary, borderRadius: radius.md, alignItems: 'center' },
  cancelText: { color: colors.onSurface, fontSize: 15, fontWeight: '500' },
  dangerBtn: { flex: 1, paddingVertical: 14, backgroundColor: colors.error, borderRadius: radius.md, alignItems: 'center' },
  dangerText: { color: colors.onBrand, fontSize: 15, fontWeight: '500' },

  switchRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surfaceTertiary, borderRadius: radius.md, padding: spacing.md, gap: spacing.md },
  switchLabel: { fontSize: 14, color: colors.onSurface, fontWeight: '500' },
  switchSub: { fontSize: 12, color: colors.onSurfaceTertiary, marginTop: 2 },
  useLocationBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: spacing.sm, paddingVertical: 8 },
  useLocationText: { color: colors.brand, fontSize: 13, fontWeight: '500' },

  alertRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: colors.border },
  alertDot: { width: 10, height: 10, borderRadius: 5 },
  alertName: { fontSize: 14, color: colors.onSurface, fontWeight: '500' },
  alertMeta: { fontSize: 12, color: colors.onSurfaceTertiary, marginTop: 2, textTransform: 'capitalize' },
  alertBadgeWarn: { backgroundColor: '#FFF3CD', color: '#8A5D00', fontSize: 12, fontWeight: '500', paddingHorizontal: 8, paddingVertical: 4, borderRadius: radius.sm },
  alertBadgeErr: { backgroundColor: '#FDECEE', color: colors.error, fontSize: 12, fontWeight: '500', paddingHorizontal: 8, paddingVertical: 4, borderRadius: radius.sm },
});
