import { useCallback, useState } from 'react';
import {
  View, Text, StyleSheet, Pressable, ScrollView, ActivityIndicator, RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useFocusEffect } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { api, Punch, PunchType, Schedule } from '@/src/api';
import { colors, spacing, radius } from '@/src/theme';

const PUNCH_ORDER: PunchType[] = ['entrada', 'inicio_intervalo', 'fim_intervalo', 'saida'];
const PUNCH_LABELS: Record<PunchType, string> = {
  entrada: 'Entrada',
  inicio_intervalo: 'Início Intervalo',
  fim_intervalo: 'Fim Intervalo',
  saida: 'Saída',
};

function todayRange() {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
  const end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999).toISOString();
  return { start, end };
}

function formatTime(iso: string) {
  const d = new Date(iso);
  return d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

export default function Home() {
  const router = useRouter();
  const [punches, setPunches] = useState<Punch[]>([]);
  const [schedule, setSchedule] = useState<Schedule | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [userName, setUserName] = useState('');

  const load = useCallback(async () => {
    try {
      const { start, end } = todayRange();
      const [me, sch, ps] = await Promise.all([
        api.me().catch(() => null),
        api.getSchedule(),
        api.listPunches(start, end),
      ]);
      if (me) setUserName(me.name);
      setSchedule(sch);
      setPunches(ps);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const doneTypes = new Set(punches.map((p) => p.type));
  const nextType: PunchType | null = PUNCH_ORDER.find((t) => !doneTypes.has(t)) ?? null;

  const currentState = (() => {
    if (doneTypes.has('saida')) return { label: 'Jornada encerrada', color: colors.onSurfaceTertiary };
    if (doneTypes.has('fim_intervalo')) return { label: 'Trabalhando', color: colors.brand };
    if (doneTypes.has('inicio_intervalo')) return { label: 'Em intervalo', color: colors.warning };
    if (doneTypes.has('entrada')) return { label: 'Trabalhando', color: colors.brand };
    return { label: 'Fora do expediente', color: colors.onSurfaceTertiary };
  })();

  const onPunch = () => {
    if (!nextType) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.push({ pathname: '/punch', params: { type: nextType } });
  };

  const onRefresh = () => {
    setRefreshing(true);
    load();
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <ActivityIndicator color={colors.brand} size="large" style={{ marginTop: 100 }} />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']} testID="home-screen">
      <ScrollView
        contentContainerStyle={styles.scroll}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.brand} />}
      >
        <View style={styles.header}>
          <Text style={styles.greeting}>Olá, {userName || 'Bem-vindo'}</Text>
          <Text style={styles.date}>
            {new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' })}
          </Text>
        </View>

        <View style={styles.hero}>
          <View style={[styles.statusDot, { backgroundColor: currentState.color }]} />
          <Text style={styles.statusLabel} testID="current-status">{currentState.label}</Text>
          {schedule && (
            <Text style={styles.scheduleText}>
              Jornada: {schedule.start_time} — {schedule.end_time} · Intervalo {schedule.interval_minutes}min
            </Text>
          )}
        </View>

        <Text style={styles.sectionTitle}>Pontos de hoje</Text>
        <View style={styles.timeline}>
          {PUNCH_ORDER.map((t) => {
            const found = punches.find((p) => p.type === t);
            return (
              <View key={t} style={styles.punchRow} testID={`punch-row-${t}`}>
                <View
                  style={[styles.punchDot, { backgroundColor: found ? colors.brand : colors.border }]}
                />
                <View style={{ flex: 1 }}>
                  <Text style={styles.punchLabel}>{PUNCH_LABELS[t]}</Text>
                  <Text style={styles.punchTime}>
                    {found ? formatTime(found.timestamp) : '— não registrado'}
                  </Text>
                </View>
                {found && <Feather name="check-circle" size={20} color={colors.brand} />}
              </View>
            );
          })}
        </View>
      </ScrollView>

      <View style={styles.ctaWrap}>
        <Pressable
          testID="punch-cta"
          onPress={onPunch}
          disabled={!nextType}
          style={({ pressed }) => [
            styles.cta,
            !nextType && styles.ctaDisabled,
            pressed && { opacity: 0.85 },
          ]}
        >
          <Feather name="camera" size={20} color={colors.onBrand} />
          <Text style={styles.ctaText}>
            {nextType ? `Bater Ponto · ${PUNCH_LABELS[nextType]}` : 'Jornada concluída'}
          </Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.surface },
  scroll: { paddingHorizontal: spacing.lg, paddingBottom: 120 },
  header: { paddingTop: spacing.md, paddingBottom: spacing.lg },
  greeting: { fontSize: 22, fontWeight: '500', color: colors.onSurface },
  date: { fontSize: 13, color: colors.onSurfaceTertiary, marginTop: 4, textTransform: 'capitalize' },
  hero: {
    backgroundColor: colors.surfaceSecondary, borderRadius: radius.lg, padding: spacing.lg,
    borderWidth: 1, borderColor: colors.border, marginBottom: spacing.xl,
  },
  statusDot: { width: 12, height: 12, borderRadius: 6, marginBottom: spacing.sm },
  statusLabel: { fontSize: 20, fontWeight: '500', color: colors.onSurface, marginBottom: spacing.xs },
  scheduleText: { fontSize: 13, color: colors.onSurfaceTertiary },
  sectionTitle: { fontSize: 13, color: colors.onSurfaceTertiary, marginBottom: spacing.sm, textTransform: 'uppercase', letterSpacing: 0.5 },
  timeline: { backgroundColor: colors.surfaceSecondary, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, overflow: 'hidden' },
  punchRow: {
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.border, gap: spacing.md,
  },
  punchDot: { width: 12, height: 12, borderRadius: 6 },
  punchLabel: { fontSize: 15, color: colors.onSurface, fontWeight: '500' },
  punchTime: { fontSize: 13, color: colors.onSurfaceTertiary, marginTop: 2 },
  ctaWrap: {
    position: 'absolute', bottom: 80, left: spacing.lg, right: spacing.lg,
  },
  cta: {
    backgroundColor: colors.brand, borderRadius: radius.lg, paddingVertical: 18,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.sm,
    shadowColor: colors.brandDark, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.2, shadowRadius: 12, elevation: 4,
  },
  ctaDisabled: { backgroundColor: colors.borderStrong },
  ctaText: { color: colors.onBrand, fontSize: 16, fontWeight: '500' },
});
