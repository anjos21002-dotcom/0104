import { useCallback, useState } from 'react';
import { View, Text, Pressable, StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useFocusEffect } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { api, clearToken, Schedule } from '@/src/api';
import { colors, spacing, radius } from '@/src/theme';
import CeoFooter from '@/src/components/CeoFooter';

export default function Settings() {
  const router = useRouter();
  const [schedule, setSchedule] = useState<Schedule>({ start_time: '09:00', interval_minutes: 60, end_time: '17:20' });
  const [user, setUser] = useState<{ name: string; email: string; role: string } | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const [me, sch] = await Promise.all([api.me(), api.getSchedule()]);
      setUser({ name: me.name, email: me.email, role: me.role });
      setSchedule(sch);
    } finally { setLoading(false); }
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  const logout = async () => { await clearToken(); router.replace('/login'); };
  if (loading) return <SafeAreaView style={styles.container}><ActivityIndicator color={colors.brand} style={{ marginTop: 100 }} /></SafeAreaView>;

  return (
    <SafeAreaView style={styles.container} edges={['top']} testID="settings-screen">
      <ScrollView contentContainerStyle={{ paddingBottom: 120 }}>
        <View style={styles.header}><Text style={styles.title}>Ajustes</Text></View>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>PERFIL</Text>
          <View style={styles.card}>
            <View style={styles.row}><Feather name="user" size={18} color={colors.onSurfaceSecondary} /><Text style={styles.rowText}>{user?.name}</Text></View>
            <View style={styles.divider} />
            <View style={styles.row}><Feather name="mail" size={18} color={colors.onSurfaceSecondary} /><Text style={styles.rowText}>{user?.email}</Text></View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>MINHA JORNADA</Text>
          <View style={styles.card}>
            <View style={styles.fieldRow}><Text style={styles.fieldLabel}>Horário de início</Text><Text style={styles.fieldValue}>{schedule.start_time}</Text></View>
            <View style={styles.divider} />
            <View style={styles.fieldRow}><Text style={styles.fieldLabel}>Intervalo</Text><Text style={styles.fieldValue}>{schedule.interval_minutes} min</Text></View>
            <View style={styles.divider} />
            <View style={styles.fieldRow}><Text style={styles.fieldLabel}>Horário de largada</Text><Text style={styles.fieldValue}>{schedule.end_time}</Text></View>
          </View>
          <View style={styles.infoBox}><Feather name="lock" size={15} color={colors.brandDark}/><Text style={styles.infoText}>A jornada é configurada pelo administrador. O funcionário pode consultar, mas não alterar.</Text></View>
        </View>

        <View style={styles.section}><Pressable testID="logout-button" onPress={logout} style={styles.logoutBtn}><Feather name="log-out" size={18} color={colors.error} /><Text style={styles.logoutText}>Sair</Text></Pressable></View>
        <View style={[styles.section, { marginBottom: spacing.xl }]}><CeoFooter /></View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,backgroundColor:colors.surfaceTertiary},header:{paddingHorizontal:spacing.lg,paddingTop:spacing.md,paddingBottom:spacing.md},title:{fontSize:22,fontWeight:'500',color:colors.onSurface},section:{paddingHorizontal:spacing.lg,marginTop:spacing.lg},sectionTitle:{fontSize:12,color:colors.onSurfaceTertiary,textTransform:'uppercase',letterSpacing:.6,marginBottom:spacing.sm,paddingHorizontal:spacing.xs},card:{backgroundColor:colors.surfaceSecondary,borderRadius:radius.md,overflow:'hidden',borderWidth:1,borderColor:colors.border},row:{flexDirection:'row',alignItems:'center',paddingHorizontal:spacing.lg,paddingVertical:14,gap:spacing.md},rowText:{color:colors.onSurface,fontSize:15},divider:{height:1,backgroundColor:colors.border,marginLeft:spacing.lg},fieldRow:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingHorizontal:spacing.lg,paddingVertical:14},fieldLabel:{color:colors.onSurface,fontSize:15},fieldValue:{color:colors.brandDark,fontSize:15,fontWeight:'600'},infoBox:{flexDirection:'row',gap:spacing.sm,backgroundColor:colors.brandLight,borderRadius:radius.sm,padding:spacing.md,marginTop:spacing.sm},infoText:{flex:1,fontSize:12,color:colors.brandDark,lineHeight:17},logoutBtn:{backgroundColor:colors.surfaceSecondary,borderRadius:radius.md,paddingVertical:14,flexDirection:'row',alignItems:'center',justifyContent:'center',gap:spacing.sm,borderWidth:1,borderColor:colors.border},logoutText:{color:colors.error,fontSize:15,fontWeight:'500'}
});
