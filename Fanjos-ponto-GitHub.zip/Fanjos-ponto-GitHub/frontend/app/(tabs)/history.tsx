import { useCallback, useMemo, useState } from 'react';
import { View, Text, StyleSheet, Pressable, ScrollView, ActivityIndicator, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import * as Haptics from 'expo-haptics';
import { api, Punch, PunchType, TimeSheet } from '@/src/api';
import { colors, spacing, radius } from '@/src/theme';

const PUNCH_LABELS: Record<PunchType, string> = { entrada: 'Entrada', inicio_intervalo: 'Início Intervalo', fim_intervalo: 'Fim Intervalo', saida: 'Saída' };
type Period = 'week' | 'month' | 'all';

function periodRange(p: Period) {
  const now = new Date();
  const end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999).toISOString();
  let start: string;
  if (p === 'week') { const d = new Date(now); d.setDate(d.getDate() - 6); d.setHours(0, 0, 0, 0); start = d.toISOString(); }
  else if (p === 'month') start = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
  else start = new Date(2000, 0, 1).toISOString();
  return { start, end };
}
function formatTime(iso: string) { return new Date(iso).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }); }
function formatDate(dateKey: string) { const [y,m,d]=dateKey.split('-'); return new Date(Number(y),Number(m)-1,Number(d)).toLocaleDateString('pt-BR',{weekday:'short',day:'2-digit',month:'short'}); }
function fmtMinutes(v: number, signed = false) { const sign = signed ? (v > 0 ? '+' : v < 0 ? '-' : '') : ''; const n = Math.abs(Math.round(v)); return `${sign}${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`; }
const STATUS: Record<string,string> = { normal:'Normal', falta:'Falta', incompleto:'Incompleto', em_andamento:'Em andamento', atestado:'Atestado', autorizado:'Autorizado', ferias:'Férias' };

export default function History() {
  const [period, setPeriod] = useState<Period>('month');
  const [punches, setPunches] = useState<Punch[]>([]);
  const [sheet, setSheet] = useState<TimeSheet | null>(null);
  const [loading, setLoading] = useState(true); const [refreshing, setRefreshing] = useState(false); const [exporting, setExporting] = useState(false);

  const load = useCallback(async () => {
    try {
      const { start, end } = periodRange(period);
      const [list, ts] = await Promise.all([api.listPunches(start, end), api.myTimeSheet(start, end)]);
      setPunches(list); setSheet(ts);
    } finally { setLoading(false); setRefreshing(false); }
  }, [period]);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  const groups = useMemo(() => {
    const map: Record<string, Punch[]> = {};
    for (const p of punches) { const local = new Date(p.timestamp); const key = `${local.getFullYear()}-${String(local.getMonth()+1).padStart(2,'0')}-${String(local.getDate()).padStart(2,'0')}`; (map[key] ||= []).push(p); }
    return Object.entries(map).sort(([a],[b]) => a < b ? 1 : -1);
  }, [punches]);
  const dayByDate = useMemo(() => Object.fromEntries((sheet?.days || []).map((d) => [d.date, d])), [sheet]);

  const onExport = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); setExporting(true);
    try {
      const { start, end } = periodRange(period); const html = await api.fetchExportHtml(start, end);
      const uri = FileSystem.documentDirectory + `folha_ponto_${period}_${new Date().toISOString().slice(0,10)}.html`;
      await FileSystem.writeAsStringAsync(uri, html, { encoding: FileSystem.EncodingType.UTF8 });
      if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(uri, { mimeType: 'text/html', dialogTitle: 'Folha de Ponto' });
    } finally { setExporting(false); }
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']} testID="history-screen">
      <View style={styles.header}><Text style={styles.title}>Meu Ponto</Text><Text style={styles.subtitle}>Folha de ponto e banco de horas</Text></View>
      <View style={styles.chipRow}>{(['week','month','all'] as Period[]).map((p) => {
        const label=p==='week'?'Semana':p==='month'?'Mês':'Tudo'; const active=period===p;
        return <Pressable key={p} onPress={() => setPeriod(p)} style={[styles.chip,active&&styles.chipActive]}><Text style={[styles.chipText,active&&styles.chipTextActive]}>{label}</Text></Pressable>;
      })}</View>

      {loading ? <ActivityIndicator color={colors.brand} style={{marginTop:40}} /> : (
        <ScrollView contentContainerStyle={{padding:spacing.lg,paddingBottom:150}} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => {setRefreshing(true);load();}} tintColor={colors.brand} />}>
          {sheet && <>
            <View style={styles.balanceCard}>
              <Text style={styles.balanceLabel}>SALDO DO BANCO DE HORAS</Text>
              <Text style={[styles.balanceValue, sheet.summary.balance_minutes < 0 && {color:colors.error}]}>{fmtMinutes(sheet.summary.balance_minutes,true)}</Text>
              <Text style={styles.balanceSub}>Jornada {sheet.schedule.start_time} às {sheet.schedule.end_time} · {sheet.schedule.interval_minutes} min de intervalo</Text>
            </View>
            <View style={styles.statsRow}>
              <View style={styles.stat}><Text style={styles.statLabel}>Extras</Text><Text style={styles.statValue}>{fmtMinutes(sheet.summary.extra_minutes)}</Text></View>
              <View style={styles.stat}><Text style={styles.statLabel}>Negativas</Text><Text style={[styles.statValue,{color:colors.error}]}>{fmtMinutes(sheet.summary.negative_minutes)}</Text></View>
              <View style={styles.stat}><Text style={styles.statLabel}>Trabalhadas</Text><Text style={styles.statValue}>{fmtMinutes(sheet.summary.worked_minutes)}</Text></View>
            </View>
            <View style={styles.ruleBox}><Feather name="info" size={16} color={colors.brandDark}/><Text style={styles.ruleText}>Atraso: conta quando passar de 15 min. Hora extra: conta quando passar de 10 min. Ao ultrapassar, o período inteiro entra no cálculo.</Text></View>
          </>}

          {groups.length === 0 ? <View style={styles.empty}><Feather name="inbox" size={48} color={colors.onSurfaceTertiary}/><Text style={styles.emptyText}>Nenhum ponto registrado neste período</Text></View> : groups.map(([date,list]) => {
            const day=dayByDate[date];
            return <View key={date} style={styles.card} testID={`day-card-${date}`}>
              <View style={styles.cardHeader}><View><Text style={styles.cardDate}>{formatDate(date)}</Text><Text style={styles.statusText}>{STATUS[day?.status || 'normal'] || day?.status}</Text></View><Text style={[styles.cardBalance,(day?.balance_minutes||0)<0&&{color:colors.error}]}>{day ? fmtMinutes(day.balance_minutes,true) : '—'}</Text></View>
              {list.map((p) => <View key={p.id} style={styles.punchLine}><View style={styles.dot}/><Text style={styles.punchLabel}>{PUNCH_LABELS[p.type]}</Text>{p.within_geofence===false&&<Feather name="alert-circle" size={12} color={colors.warning}/>}<Text style={styles.punchTime}>{formatTime(p.timestamp)}</Text></View>)}
              {day && <View style={styles.dayFooter}><Text style={styles.dayFooterText}>Trabalhado {fmtMinutes(day.worked_minutes)}</Text>{day.credited_minutes>0&&<Text style={styles.dayFooterText}>Abonado {fmtMinutes(day.credited_minutes)}</Text>}</View>}
            </View>;
          })}
        </ScrollView>
      )}

      <View style={styles.exportWrap}><Pressable onPress={onExport} disabled={exporting} style={({pressed})=>[styles.exportBtn,pressed&&{opacity:.85}]}>{exporting?<ActivityIndicator color={colors.onBrand}/>:<><Feather name="download" size={18} color={colors.onBrand}/><Text style={styles.exportText}>Baixar Folha de Ponto</Text></>}</Pressable></View>
    </SafeAreaView>
  );
}

const styles=StyleSheet.create({
  container:{flex:1,backgroundColor:colors.surfaceTertiary}, header:{paddingHorizontal:spacing.lg,paddingTop:spacing.md,paddingBottom:spacing.xs}, title:{fontSize:22,fontWeight:'600',color:colors.onSurface}, subtitle:{fontSize:13,color:colors.onSurfaceTertiary,marginTop:2},
  chipRow:{flexDirection:'row',gap:spacing.sm,paddingHorizontal:spacing.lg,paddingVertical:spacing.md}, chip:{paddingHorizontal:spacing.lg,height:36,borderRadius:radius.pill,borderWidth:1,borderColor:colors.border,backgroundColor:colors.surfaceSecondary,alignItems:'center',justifyContent:'center'}, chipActive:{backgroundColor:colors.brand,borderColor:colors.brand}, chipText:{color:colors.onSurfaceSecondary,fontSize:13,fontWeight:'500'},chipTextActive:{color:colors.onBrand},
  balanceCard:{backgroundColor:colors.brandDark,borderRadius:radius.lg,padding:spacing.xl,marginBottom:spacing.md},balanceLabel:{fontSize:11,color:'#D8F3DC',letterSpacing:.8},balanceValue:{fontSize:36,fontWeight:'700',color:colors.onBrand,marginTop:6},balanceSub:{fontSize:12,color:'#D8F3DC',marginTop:8},
  statsRow:{flexDirection:'row',gap:spacing.sm,marginBottom:spacing.md},stat:{flex:1,backgroundColor:colors.surfaceSecondary,borderRadius:radius.md,padding:spacing.md,borderWidth:1,borderColor:colors.border},statLabel:{fontSize:11,color:colors.onSurfaceTertiary},statValue:{fontSize:18,fontWeight:'600',color:colors.brandDark,marginTop:4},
  ruleBox:{flexDirection:'row',gap:spacing.sm,backgroundColor:colors.brandLight,padding:spacing.md,borderRadius:radius.md,marginBottom:spacing.lg},ruleText:{flex:1,fontSize:12,color:colors.brandDark,lineHeight:17},
  empty:{alignItems:'center',paddingTop:50,gap:spacing.md},emptyText:{color:colors.onSurfaceTertiary,fontSize:14},card:{backgroundColor:colors.surfaceSecondary,borderRadius:radius.lg,padding:spacing.lg,borderWidth:1,borderColor:colors.border,marginBottom:spacing.md},cardHeader:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:spacing.sm},cardDate:{fontSize:15,fontWeight:'600',color:colors.onSurface,textTransform:'capitalize'},statusText:{fontSize:11,color:colors.onSurfaceTertiary,marginTop:2},cardBalance:{fontSize:18,fontWeight:'700',color:colors.brand},punchLine:{flexDirection:'row',alignItems:'center',paddingVertical:6,gap:spacing.md},dot:{width:8,height:8,borderRadius:4,backgroundColor:colors.brand},punchLabel:{flex:1,color:colors.onSurfaceSecondary,fontSize:14},punchTime:{color:colors.onSurface,fontSize:14,fontWeight:'500'},dayFooter:{flexDirection:'row',gap:spacing.lg,borderTopWidth:1,borderTopColor:colors.border,marginTop:spacing.sm,paddingTop:spacing.sm},dayFooterText:{fontSize:11,color:colors.onSurfaceTertiary},
  exportWrap:{position:'absolute',bottom:80,left:spacing.lg,right:spacing.lg},exportBtn:{backgroundColor:colors.brand,borderRadius:radius.lg,paddingVertical:16,flexDirection:'row',alignItems:'center',justifyContent:'center',gap:spacing.sm,shadowColor:colors.brandDark,shadowOffset:{width:0,height:4},shadowOpacity:.2,shadowRadius:12,elevation:4},exportText:{color:colors.onBrand,fontSize:15,fontWeight:'600'}
});
