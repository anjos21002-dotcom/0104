import { useEffect, useRef, useState } from 'react';
import {
  View, Text, StyleSheet, Pressable, ActivityIndicator, Platform, Image as RNImage,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as Location from 'expo-location';
import * as Haptics from 'expo-haptics';
import { Feather } from '@expo/vector-icons';
import { api, PunchType } from '@/src/api';
import { colors, spacing, radius } from '@/src/theme';

const LABELS: Record<PunchType, string> = {
  entrada: 'Entrada',
  inicio_intervalo: 'Início do Intervalo',
  fim_intervalo: 'Fim do Intervalo',
  saida: 'Saída',
};

export default function PunchScreen() {
  const router = useRouter();
  const { type } = useLocalSearchParams<{ type: PunchType }>();
  const punchType: PunchType = (type as PunchType) || 'entrada';

  const [camPerm, requestCamPerm] = useCameraPermissions();
  const [locPerm, setLocPerm] = useState<Location.LocationPermissionResponse | null>(null);
  const [location, setLocation] = useState<Location.LocationObject | null>(null);
  const [locError, setLocError] = useState<string | null>(null);
  const [photoUri, setPhotoUri] = useState<string | null>(null);
  const [taking, setTaking] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const cameraRef = useRef<CameraView>(null);

  useEffect(() => {
    (async () => {
      const p = await Location.requestForegroundPermissionsAsync();
      setLocPerm(p);
      if (p.granted) {
        try {
          const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
          setLocation(loc);
        } catch (e: any) {
          setLocError('Não foi possível obter localização');
        }
      }
    })();
  }, []);

  useEffect(() => {
    if (camPerm && !camPerm.granted && camPerm.canAskAgain) {
      requestCamPerm();
    }
  }, [camPerm]);

  const takePhoto = async () => {
    if (!cameraRef.current || taking) return;
    setTaking(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    try {
      const photo = await cameraRef.current.takePictureAsync({ quality: 0.6, base64: false });
      if (photo?.uri) setPhotoUri(photo.uri);
    } catch (e: any) {
      setError('Erro ao capturar foto');
    }
    setTaking(false);
  };

  const retake = () => setPhotoUri(null);

  const confirm = async () => {
    if (!photoUri || !location) return;
    setConfirming(true);
    setError(null);
    try {
      const uploaded = await api.uploadPhoto(photoUri);
      await api.createPunch({
        type: punchType,
        photo_path: uploaded.path,
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
        accuracy: location.coords.accuracy ?? undefined,
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.back();
    } catch (e: any) {
      setError(e.message || 'Erro ao registrar ponto');
    } finally {
      setConfirming(false);
    }
  };

  if (!camPerm) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.brand} />
      </View>
    );
  }

  if (!camPerm.granted) {
    return (
      <SafeAreaView style={styles.container} testID="punch-screen">
        <View style={styles.blockedBox}>
          <Feather name="camera-off" size={40} color={colors.error} />
          <Text style={styles.blockedTitle}>Permissão de câmera necessária</Text>
          <Text style={styles.blockedDesc}>Para bater ponto, é preciso permitir o acesso à câmera.</Text>
          <Pressable style={styles.confirmBtn} onPress={requestCamPerm} testID="request-camera-perm">
            <Text style={styles.confirmText}>Permitir Câmera</Text>
          </Pressable>
          <Pressable onPress={() => router.back()} style={{ marginTop: spacing.md }}>
            <Text style={{ color: colors.onSurfaceTertiary }}>Cancelar</Text>
          </Pressable>
        </View>
      </SafeAreaView>
    );
  }

  if (locPerm && !locPerm.granted) {
    return (
      <SafeAreaView style={styles.container} testID="punch-screen">
        <View style={styles.blockedBox}>
          <Feather name="map-pin" size={40} color={colors.error} />
          <Text style={styles.blockedTitle}>Permissão de localização necessária</Text>
          <Text style={styles.blockedDesc}>Ative a localização para registrar onde o ponto foi batido.</Text>
          <Pressable
            style={styles.confirmBtn}
            onPress={async () => setLocPerm(await Location.requestForegroundPermissionsAsync())}
            testID="request-location-perm"
          >
            <Text style={styles.confirmText}>Permitir Localização</Text>
          </Pressable>
          <Pressable onPress={() => router.back()} style={{ marginTop: spacing.md }}>
            <Text style={{ color: colors.onSurfaceTertiary }}>Cancelar</Text>
          </Pressable>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <View style={styles.container} testID="punch-screen">
      {/* Header */}
      <SafeAreaView edges={['top']} style={styles.headerSafe}>
        <View style={styles.headerRow}>
          <Pressable onPress={() => router.back()} style={styles.headerBtn} testID="punch-close">
            <Feather name="x" size={22} color={colors.onSurface} />
          </Pressable>
          <View style={{ alignItems: 'center' }}>
            <Text style={styles.headerLabel}>{LABELS[punchType]}</Text>
            <Text style={styles.headerTime}>
              {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
            </Text>
          </View>
          <View style={{ width: 32 }} />
        </View>
      </SafeAreaView>

      {/* Camera / Photo preview */}
      <View style={styles.cameraArea}>
        {photoUri ? (
          <RNImage source={{ uri: photoUri }} style={styles.preview} resizeMode="cover" />
        ) : (
          <CameraView ref={cameraRef} style={StyleSheet.absoluteFill} facing="front" />
        )}
      </View>

      {/* GPS info */}
      <View style={styles.gpsCard}>
        <View style={styles.gpsRow}>
          <Feather name="map-pin" size={18} color={colors.brand} />
          {location ? (
            <Text style={styles.gpsText}>
              {location.coords.latitude.toFixed(6)}, {location.coords.longitude.toFixed(6)}
              {location.coords.accuracy ? `  ±${Math.round(location.coords.accuracy)}m` : ''}
            </Text>
          ) : (
            <Text style={styles.gpsText}>{locError || 'Obtendo localização…'}</Text>
          )}
        </View>
      </View>

      {error && <Text style={styles.error} testID="punch-error">{error}</Text>}

      {/* Bottom actions */}
      <SafeAreaView edges={['bottom']} style={styles.bottomSafe}>
        {photoUri ? (
          <View style={styles.actionRow}>
            <Pressable style={styles.secondaryBtn} onPress={retake} testID="retake-photo">
              <Feather name="rotate-ccw" size={18} color={colors.onSurface} />
              <Text style={styles.secondaryText}>Refazer</Text>
            </Pressable>
            <Pressable
              testID="confirm-punch"
              style={[styles.confirmBtn, (!location || confirming) && { opacity: 0.6 }]}
              disabled={!location || confirming}
              onPress={confirm}
            >
              {confirming ? (
                <ActivityIndicator color={colors.onBrand} />
              ) : (
                <>
                  <Feather name="check" size={18} color={colors.onBrand} />
                  <Text style={styles.confirmText}>Confirmar Ponto</Text>
                </>
              )}
            </Pressable>
          </View>
        ) : (
          <View style={styles.shutterWrap}>
            <Pressable
              testID="take-photo-button"
              onPress={takePhoto}
              disabled={taking}
              style={({ pressed }) => [styles.shutter, pressed && { opacity: 0.8 }]}
            >
              <View style={styles.shutterInner} />
            </Pressable>
          </View>
        )}
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.surface },
  headerSafe: { backgroundColor: colors.surfaceSecondary },
  headerRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
  },
  headerBtn: { width: 32, height: 32, alignItems: 'center', justifyContent: 'center' },
  headerLabel: { fontSize: 15, fontWeight: '500', color: colors.onSurface },
  headerTime: { fontSize: 13, color: colors.brand, marginTop: 2 },
  cameraArea: { flex: 1, backgroundColor: '#000', overflow: 'hidden' },
  preview: { width: '100%', height: '100%' },
  gpsCard: {
    backgroundColor: colors.surfaceSecondary, paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderTopWidth: 1, borderTopColor: colors.border,
  },
  gpsRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  gpsText: { color: colors.onSurfaceSecondary, fontSize: 13, flex: 1 },
  error: {
    color: colors.error, textAlign: 'center', paddingVertical: spacing.sm,
    backgroundColor: colors.surfaceSecondary,
  },
  bottomSafe: { backgroundColor: colors.surfaceSecondary },
  shutterWrap: { alignItems: 'center', paddingVertical: spacing.lg },
  shutter: {
    width: 72, height: 72, borderRadius: 36, backgroundColor: colors.brand,
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 4, borderColor: colors.onBrand,
  },
  shutterInner: { width: 24, height: 24, borderRadius: 12, backgroundColor: colors.onBrand },
  actionRow: { flexDirection: 'row', gap: spacing.md, paddingHorizontal: spacing.lg, paddingVertical: spacing.md },
  secondaryBtn: {
    flexDirection: 'row', gap: spacing.sm, alignItems: 'center', justifyContent: 'center',
    backgroundColor: colors.surfaceTertiary, borderRadius: radius.md, paddingVertical: 14,
    paddingHorizontal: spacing.lg,
  },
  secondaryText: { color: colors.onSurface, fontSize: 15, fontWeight: '500' },
  confirmBtn: {
    flex: 1, flexDirection: 'row', gap: spacing.sm, alignItems: 'center', justifyContent: 'center',
    backgroundColor: colors.brand, borderRadius: radius.md, paddingVertical: 14, paddingHorizontal: spacing.lg,
  },
  confirmText: { color: colors.onBrand, fontSize: 15, fontWeight: '500' },
  blockedBox: {
    flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: spacing.xl, gap: spacing.md,
    backgroundColor: colors.surface,
  },
  blockedTitle: { fontSize: 18, fontWeight: '500', color: colors.onSurface, textAlign: 'center' },
  blockedDesc: { color: colors.onSurfaceTertiary, textAlign: 'center', fontSize: 14, marginBottom: spacing.md },
});
