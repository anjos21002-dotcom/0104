from fastapi import FastAPI, APIRouter, HTTPException, Depends, UploadFile, File, Request, Response
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import HTMLResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from starlette.concurrency import run_in_threadpool
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
import base64
from pathlib import Path
from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional, Literal
import uuid
import bcrypt
import jwt as pyjwt
import requests
import math
from datetime import datetime, timezone, timedelta, date

BRT_OFFSET = timedelta(hours=-3)  # Horário Brasília (sem DST desde 2019)


def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    R = 6371000.0
    p1 = math.radians(lat1); p2 = math.radians(lat2)
    dp = math.radians(lat2 - lat1); dl = math.radians(lon2 - lon1)
    a = math.sin(dp/2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl/2) ** 2
    return 2 * R * math.asin(math.sqrt(a))


def to_brt(iso_utc: str) -> datetime:
    dt = datetime.fromisoformat(iso_utc.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone(BRT_OFFSET))


def parse_hhmm(s: str) -> Optional[tuple[int, int]]:
    try:
        h, m = s.split(":")
        return int(h), int(m)
    except Exception:
        return None


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

JWT_SECRET = os.environ.get('JWT_SECRET', 'change-me')
JWT_ALGO = "HS256"
JWT_EXP_DAYS = 30

# Storage config
STORAGE_BASE = (os.environ.get("INTEGRATION_PROXY_URL") or "").strip() or "https://integrations.emergentagent.com"
STORAGE_URL = STORAGE_BASE.rstrip("/") + "/objstore/api/v1/storage"
EMERGENT_KEY = os.environ.get("EMERGENT_LLM_KEY")
APP_NAME = "pontocerto"
storage_key: Optional[str] = None

app = FastAPI()
api_router = APIRouter(prefix="/api")
security = HTTPBearer(auto_error=False)

logger = logging.getLogger(__name__)


def init_storage():
    global storage_key
    if storage_key:
        return storage_key
    resp = requests.post(f"{STORAGE_URL}/init", json={"emergent_key": EMERGENT_KEY}, timeout=30)
    resp.raise_for_status()
    storage_key = resp.json()["storage_key"]
    return storage_key


def put_object(path: str, data: bytes, content_type: str) -> dict:
    global storage_key
    key = init_storage()
    try:
        resp = requests.put(f"{STORAGE_URL}/objects/{path}",
            headers={"X-Storage-Key": key, "Content-Type": content_type}, data=data, timeout=120)
        if resp.status_code == 503:
            storage_key = None
            key = init_storage()
            resp = requests.put(f"{STORAGE_URL}/objects/{path}",
                headers={"X-Storage-Key": key, "Content-Type": content_type}, data=data, timeout=120)
        resp.raise_for_status()
        return resp.json()
    except requests.HTTPError as e:
        raise HTTPException(status_code=e.response.status_code, detail=f"Storage upload failed: {e.response.text}")


def get_object(path: str) -> tuple[bytes, str]:
    global storage_key
    key = init_storage()
    resp = requests.get(f"{STORAGE_URL}/objects/{path}",
        headers={"X-Storage-Key": key}, timeout=60)
    if resp.status_code == 503:
        storage_key = None
        key = init_storage()
        resp = requests.get(f"{STORAGE_URL}/objects/{path}",
            headers={"X-Storage-Key": key}, timeout=60)
    resp.raise_for_status()
    return resp.content, resp.headers.get("Content-Type", "application/octet-stream")


# ---------- Models ----------
class UserCreate(BaseModel):
    email: EmailStr
    password: str
    name: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserOut(BaseModel):
    id: str
    email: str
    name: str
    role: str = "user"

class AdminCreateUser(BaseModel):
    email: EmailStr
    password: str
    name: str
    role: str = "user"

class AdminResetPassword(BaseModel):
    password: str

class ForgotPasswordRequest(BaseModel):
    email: EmailStr

class AdminUpdateUser(BaseModel):
    name: str
    email: EmailStr
    role: Literal["user", "admin"] = "user"

class ManualPunchCreate(BaseModel):
    type: Literal["entrada", "inicio_intervalo", "fim_intervalo", "saida"]
    date: str
    time: str

class AdjustmentCreate(BaseModel):
    date: str
    kind: Literal["atestado", "autorizado", "ferias", "abono_horas", "banco_horas"]
    minutes: int = 0
    note: Optional[str] = None

class TokenOut(BaseModel):
    token: str
    user: UserOut

class Schedule(BaseModel):
    start_time: str = "09:00"
    interval_minutes: int = 60
    end_time: str = "17:20"

class PunchCreate(BaseModel):
    type: Literal["entrada", "inicio_intervalo", "fim_intervalo", "saida"]
    photo_path: str
    latitude: float
    longitude: float
    accuracy: Optional[float] = None

class PunchOut(BaseModel):
    id: str
    type: str
    photo_path: str
    latitude: float
    longitude: float
    accuracy: Optional[float] = None
    timestamp: str
    within_geofence: Optional[bool] = None
    distance_m: Optional[float] = None

class WorkLocation(BaseModel):
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    radius_m: int = 200
    address: Optional[str] = None
    enabled: bool = False


# ---------- Auth helpers ----------
def hash_password(pw: str) -> str:
    return bcrypt.hashpw(pw.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(pw: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(pw.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False


def create_token(user_id: str) -> str:
    payload = {
        "sub": user_id,
        "exp": datetime.now(timezone.utc) + timedelta(days=JWT_EXP_DAYS),
        "iat": datetime.now(timezone.utc),
    }
    return pyjwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGO)


async def get_current_user(creds: Optional[HTTPAuthorizationCredentials] = Depends(security)):
    if not creds:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        payload = pyjwt.decode(creds.credentials, JWT_SECRET, algorithms=[JWT_ALGO])
        user_id = payload.get("sub")
    except pyjwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


async def require_admin(user=Depends(get_current_user)):
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Requer permissão de administrador")
    return user


async def get_user_from_query_token(token: str):
    try:
        payload = pyjwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGO])
        user_id = payload.get("sub")
    except pyjwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


# ---------- Routes ----------
@api_router.get("/")
async def root():
    return {"message": "PontoCerto API"}


@api_router.post("/auth/register", response_model=TokenOut)
async def register(data: UserCreate):
    existing = await db.users.find_one({"email": data.email.lower()})
    if existing:
        raise HTTPException(status_code=400, detail="Email já cadastrado")
    user_id = str(uuid.uuid4())
    user_doc = {
        "id": user_id,
        "email": data.email.lower(),
        "name": data.name,
        "password_hash": hash_password(data.password),
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.users.insert_one(user_doc)
    # default schedule
    await db.schedules.insert_one({
        "user_id": user_id,
        "start_time": "09:00",
        "interval_minutes": 60,
        "end_time": "17:20",
    })
    token = create_token(user_id)
    return TokenOut(token=token, user=UserOut(id=user_id, email=data.email.lower(), name=data.name))


@api_router.post("/auth/login", response_model=TokenOut)
async def login(data: UserLogin):
    user = await db.users.find_one({"email": data.email.lower()}, {"_id": 0})
    if not user or not verify_password(data.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Credenciais inválidas")
    token = create_token(user["id"])
    return TokenOut(token=token, user=UserOut(id=user["id"], email=user["email"], name=user["name"], role=user.get("role", "user")))


@api_router.post("/auth/forgot-password")
async def forgot_password(data: ForgotPasswordRequest):
    """Creates a password reset request for an administrator without exposing account existence."""
    email = data.email.lower()
    user = await db.users.find_one({"email": email}, {"_id": 0})
    if user:
        existing = await db.password_reset_requests.find_one({"user_id": user["id"], "status": "pending"})
        if not existing:
            await db.password_reset_requests.insert_one({
                "id": str(uuid.uuid4()),
                "user_id": user["id"],
                "email": email,
                "name": user.get("name", ""),
                "status": "pending",
                "created_at": datetime.now(timezone.utc).isoformat(),
            })
    return {"ok": True, "message": "Se o e-mail estiver cadastrado, a solicitação foi enviada ao administrador."}


@api_router.get("/auth/me", response_model=UserOut)
async def me(user=Depends(get_current_user)):
    return UserOut(id=user["id"], email=user["email"], name=user["name"], role=user.get("role", "user"))


@api_router.get("/schedule", response_model=Schedule)
async def get_schedule(user=Depends(get_current_user)):
    s = await db.schedules.find_one({"user_id": user["id"]}, {"_id": 0})
    if not s:
        return Schedule()
    return Schedule(start_time=s["start_time"], interval_minutes=s["interval_minutes"], end_time=s["end_time"])


@api_router.put("/schedule", response_model=Schedule)
async def update_schedule(data: Schedule, user=Depends(require_admin)):
    await db.schedules.update_one(
        {"user_id": user["id"]},
        {"$set": {"start_time": data.start_time, "interval_minutes": data.interval_minutes, "end_time": data.end_time}},
        upsert=True,
    )
    return data


@api_router.post("/upload")
async def upload_photo(file: UploadFile = File(...), user=Depends(get_current_user)):
    ext = (file.filename or "photo.jpg").rsplit(".", 1)[-1].lower()
    if ext not in ("jpg", "jpeg", "png", "webp"):
        ext = "jpg"
    path = f"{APP_NAME}/uploads/{user['id']}/{uuid.uuid4()}.{ext}"
    data = await file.read()
    content_type = file.content_type or "image/jpeg"
    result = await run_in_threadpool(put_object, path, data, content_type)
    return {"path": result["path"], "size": result.get("size", len(data))}


@api_router.get("/files/{full_path:path}")
async def get_file(full_path: str, request: Request, token: Optional[str] = None):
    # Auth via header or query token
    auth_header = request.headers.get("authorization") or request.headers.get("Authorization")
    user = None
    if auth_header and auth_header.lower().startswith("bearer "):
        tok = auth_header.split(" ", 1)[1]
        user = await get_user_from_query_token(tok)
    elif token:
        user = await get_user_from_query_token(token)
    else:
        raise HTTPException(status_code=401, detail="Not authenticated")

    # Ownership check: path must start with APP_NAME/uploads/{user_id}/
    prefix = f"{APP_NAME}/uploads/{user['id']}/"
    if not full_path.startswith(prefix):
        raise HTTPException(status_code=403, detail="Forbidden")

    try:
        content, ct = await run_in_threadpool(get_object, full_path)
    except requests.HTTPError as e:
        raise HTTPException(status_code=404, detail="File not found")
    return Response(content=content, media_type=ct)


@api_router.post("/punches", response_model=PunchOut)
async def create_punch(data: PunchCreate, user=Depends(get_current_user)):
    punch_id = str(uuid.uuid4())
    now = datetime.now(timezone.utc)

    # Geofence evaluation
    within = None
    distance_m = None
    wl = await db.app_settings.find_one({"key": "work_location"}, {"_id": 0})
    if wl and wl.get("enabled") and wl.get("latitude") is not None and wl.get("longitude") is not None:
        distance_m = haversine_m(data.latitude, data.longitude, wl["latitude"], wl["longitude"])
        within = distance_m <= float(wl.get("radius_m", 200))

    doc = {
        "id": punch_id,
        "user_id": user["id"],
        "type": data.type,
        "photo_path": data.photo_path,
        "latitude": data.latitude,
        "longitude": data.longitude,
        "accuracy": data.accuracy,
        "timestamp": now.isoformat(),
        "within_geofence": within,
        "distance_m": distance_m,
    }
    await db.punches.insert_one(doc)
    return PunchOut(
        id=punch_id, type=data.type, photo_path=data.photo_path,
        latitude=data.latitude, longitude=data.longitude, accuracy=data.accuracy,
        timestamp=now.isoformat(), within_geofence=within, distance_m=distance_m,
    )


@api_router.get("/punches", response_model=List[PunchOut])
async def list_punches(start: Optional[str] = None, end: Optional[str] = None, user=Depends(get_current_user)):
    query = {"user_id": user["id"]}
    if start or end:
        ts = {}
        if start:
            ts["$gte"] = start
        if end:
            ts["$lte"] = end
        query["timestamp"] = ts
    docs = await db.punches.find(query, {"_id": 0}).sort("timestamp", 1).to_list(5000)
    return [PunchOut(
        id=d["id"], type=d["type"], photo_path=d["photo_path"],
        latitude=d["latitude"], longitude=d["longitude"],
        accuracy=d.get("accuracy"), timestamp=d["timestamp"],
        within_geofence=d.get("within_geofence"), distance_m=d.get("distance_m"),
    ) for d in docs]


PUNCH_LABEL = {
    "entrada": "Entrada",
    "inicio_intervalo": "Início do Intervalo",
    "fim_intervalo": "Fim do Intervalo",
    "saida": "Saída",
}


@api_router.get("/export/html", response_class=HTMLResponse)
async def export_html(start: str, end: str, user=Depends(get_current_user)):
    html = await _build_export_html(user, start, end)
    return HTMLResponse(content=html)


async def _build_timesheet(user_id: str, start: str, end: str) -> dict:
    target_user = await db.users.find_one({"id": user_id}, {"_id": 0, "password_hash": 0})
    if not target_user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    schedule = await db.schedules.find_one({"user_id": user_id}, {"_id": 0}) or {
        "start_time": "09:00", "interval_minutes": 60, "end_time": "17:20"
    }
    st = parse_hhmm(schedule.get("start_time", "09:00")) or (9, 0)
    en = parse_hhmm(schedule.get("end_time", "17:20")) or (17, 20)
    scheduled_span = (en[0] * 60 + en[1]) - (st[0] * 60 + st[1])
    scheduled_daily = max(0, scheduled_span - int(schedule.get("interval_minutes", 60)))

    start_date = to_brt(start).date()
    end_date = to_brt(end).date()
    created_at = target_user.get("created_at")
    if created_at:
        try:
            created_date = to_brt(created_at).date()
            if created_date > start_date:
                start_date = created_date
        except Exception:
            pass
    punches = await db.punches.find(
        {"user_id": user_id, "timestamp": {"$gte": start, "$lte": end}}, {"_id": 0}
    ).sort("timestamp", 1).to_list(20000)
    adjustments = await db.adjustments.find(
        {"user_id": user_id, "date": {"$gte": start_date.isoformat(), "$lte": end_date.isoformat()}}, {"_id": 0}
    ).sort("created_at", 1).to_list(5000)

    by_day: dict[str, list[dict]] = {}
    for p in punches:
        key = to_brt(p["timestamp"]).date().isoformat()
        by_day.setdefault(key, []).append(p)
    adj_by_day: dict[str, list[dict]] = {}
    for a in adjustments:
        adj_by_day.setdefault(a["date"], []).append(a)

    candidate_dates: set[str] = set(by_day) | set(adj_by_day)
    d = start_date
    while d <= end_date:
        if d.weekday() < 5:
            candidate_dates.add(d.isoformat())
        d += timedelta(days=1)

    now_local = datetime.now(timezone.utc).astimezone(timezone(BRT_OFFSET))
    days = []
    for date_key in sorted(candidate_dates):
        day_date = date.fromisoformat(date_key)
        day_punches = sorted(by_day.get(date_key, []), key=lambda x: x["timestamp"])
        day_adjustments = adj_by_day.get(date_key, [])
        is_workday = day_date.weekday() < 5
        scheduled_minutes = scheduled_daily if is_workday else 0

        entrada = next((p for p in day_punches if p["type"] == "entrada"), None)
        saidas = [p for p in day_punches if p["type"] == "saida"]
        saida = saidas[-1] if saidas else None
        inicio_int = next((p for p in day_punches if p["type"] == "inicio_intervalo"), None)
        fins_int = [p for p in day_punches if p["type"] == "fim_intervalo"]
        fim_int = fins_int[-1] if fins_int else None

        worked_minutes = 0
        actual_interval = None
        if entrada and saida:
            total = int((to_brt(saida["timestamp"]) - to_brt(entrada["timestamp"])).total_seconds() // 60)
            if inicio_int and fim_int:
                actual_interval = max(0, int((to_brt(fim_int["timestamp"]) - to_brt(inicio_int["timestamp"])).total_seconds() // 60))
            else:
                actual_interval = int(schedule.get("interval_minutes", 60)) if is_workday else 0
            worked_minutes = max(0, total - actual_interval)

        full_day_adj = next((a for a in day_adjustments if a.get("kind") in ("atestado", "autorizado", "ferias")), None)
        abono_minutes = sum(max(0, int(a.get("minutes", 0))) for a in day_adjustments if a.get("kind") == "abono_horas")
        direct_bank = sum(int(a.get("minutes", 0)) for a in day_adjustments if a.get("kind") == "banco_horas")

        effective_minutes = worked_minutes + abono_minutes
        status = "normal"
        if full_day_adj:
            effective_minutes = scheduled_minutes
            status = full_day_adj.get("kind", "abonado")

        scheduled_end_local = datetime.combine(
            day_date,
            datetime.min.time().replace(hour=en[0], minute=en[1]),
            tzinfo=timezone(BRT_OFFSET),
        )
        is_future_or_open = day_date > now_local.date() or (day_date == now_local.date() and now_local < scheduled_end_local)

        raw_delta = effective_minutes - scheduled_minutes
        bank_base = 0
        if not is_future_or_open or saida or full_day_adj:
            if full_day_adj:
                bank_base = 0
            elif raw_delta > 10:
                bank_base = raw_delta  # passou 10 min: conta o período inteiro
            elif raw_delta < -15:
                bank_base = raw_delta  # passou 15 min: desconta o período inteiro
            else:
                bank_base = 0
        elif is_workday:
            status = "em_andamento"

        if is_workday and not entrada and not full_day_adj and not is_future_or_open:
            status = "falta"
        elif is_workday and (entrada or saida) and not (entrada and saida) and not full_day_adj and not is_future_or_open:
            status = "incompleto"

        bank_minutes = bank_base + direct_bank
        arrival_late = 0
        if entrada and is_workday:
            scheduled_start_local = datetime.combine(
                day_date,
                datetime.min.time().replace(hour=st[0], minute=st[1]),
                tzinfo=timezone(BRT_OFFSET),
            )
            late = max(0, int((to_brt(entrada["timestamp"]) - scheduled_start_local).total_seconds() // 60))
            arrival_late = late if late > 15 else 0
        interval_excess = 0
        if actual_interval is not None and is_workday:
            excess = max(0, actual_interval - int(schedule.get("interval_minutes", 60)))
            interval_excess = excess if excess > 15 else 0

        days.append({
            "date": date_key,
            "is_workday": is_workday,
            "scheduled_minutes": scheduled_minutes,
            "worked_minutes": worked_minutes,
            "credited_minutes": abono_minutes,
            "bank_adjustment_minutes": direct_bank,
            "balance_minutes": bank_minutes,
            "extra_minutes": max(bank_minutes, 0),
            "negative_minutes": max(-bank_minutes, 0),
            "arrival_late_minutes": arrival_late,
            "interval_excess_minutes": interval_excess,
            "status": status,
            "punches": [
                {"id": p["id"], "type": p["type"], "timestamp": p["timestamp"], "source": p.get("source", "clock")}
                for p in day_punches
            ],
            "adjustments": [
                {"id": a["id"], "kind": a["kind"], "minutes": int(a.get("minutes", 0)), "note": a.get("note")}
                for a in day_adjustments
            ],
        })

    completed_days = [x for x in days if x["status"] != "em_andamento"]
    return {
        "user": {"id": target_user["id"], "name": target_user["name"], "email": target_user["email"]},
        "schedule": {
            "start_time": schedule.get("start_time", "09:00"),
            "interval_minutes": int(schedule.get("interval_minutes", 60)),
            "end_time": schedule.get("end_time", "17:20"),
            "daily_minutes": scheduled_daily,
        },
        "rules": {"late_tolerance_minutes": 15, "extra_tolerance_minutes": 10},
        "summary": {
            "scheduled_minutes": sum(x["scheduled_minutes"] for x in completed_days),
            "worked_minutes": sum(x["worked_minutes"] for x in completed_days),
            "credited_minutes": sum(x["credited_minutes"] for x in completed_days),
            "extra_minutes": sum(x["extra_minutes"] for x in completed_days),
            "negative_minutes": sum(x["negative_minutes"] for x in completed_days),
            "balance_minutes": sum(x["balance_minutes"] for x in completed_days),
        },
        "days": days,
    }


def _fmt_minutes_html(minutes: int, signed: bool = False) -> str:
    sign = ""
    n = int(minutes)
    if signed:
        sign = "+" if n > 0 else "-" if n < 0 else ""
    n = abs(n)
    return f"{sign}{n // 60:02d}:{n % 60:02d}"


async def _build_export_html(target_user: dict, start: str, end: str) -> str:
    sheet = await _build_timesheet(target_user["id"], start, end)
    rows = []
    for day in sheet["days"]:
        times = {p["type"]: to_brt(p["timestamp"]).strftime("%H:%M") for p in day["punches"]}
        status_labels = {
            "normal": "Normal", "falta": "Falta", "incompleto": "Incompleto", "em_andamento": "Em andamento",
            "atestado": "Atestado", "autorizado": "Autorizado", "ferias": "Férias",
        }
        rows.append(f"""
        <tr>
          <td>{day['date'][8:10]}/{day['date'][5:7]}/{day['date'][:4]}</td>
          <td>{times.get('entrada','—')}</td><td>{times.get('inicio_intervalo','—')}</td>
          <td>{times.get('fim_intervalo','—')}</td><td>{times.get('saida','—')}</td>
          <td>{_fmt_minutes_html(day['worked_minutes'])}</td>
          <td>{_fmt_minutes_html(day['balance_minutes'], True)}</td>
          <td>{status_labels.get(day['status'], day['status'])}</td>
        </tr>""")
    rows_html = "".join(rows) or '<tr><td colspan="8">Nenhum registro no período.</td></tr>'
    summary = sheet["summary"]
    schedule = sheet["schedule"]
    generated = datetime.now(timezone.utc).astimezone(timezone(BRT_OFFSET)).strftime("%d/%m/%Y %H:%M")
    return f"""<!DOCTYPE html>
<html lang="pt-BR"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Folha de Ponto - {target_user['name']}</title>
<style>
body{{font-family:Arial,sans-serif;color:#111;margin:28px}} .head{{border:2px solid #1B4332;padding:18px;border-radius:10px}}
h1{{margin:0;color:#1B4332}} .muted{{color:#666;font-size:13px}} .summary{{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0}}
.box{{border:1px solid #ddd;border-radius:8px;padding:12px;min-width:130px}} .value{{font-size:20px;font-weight:700}}
table{{width:100%;border-collapse:collapse;font-size:12px}} th,td{{border:1px solid #bbb;padding:7px;text-align:center}} th{{background:#eef7f1}}
.rules{{margin:14px 0;padding:10px;background:#fff8e6;border-radius:8px;font-size:12px}} .signatures{{display:flex;gap:60px;margin-top:70px}}
.sig{{flex:1;text-align:center;border-top:1px solid #333;padding-top:8px}} @media print{{body{{margin:10mm}} .no-print{{display:none}}}}
</style></head><body>
<div class="head"><h1>Folha / Espelho de Ponto</h1><div>{target_user['name']} · {target_user['email']}</div>
<div class="muted">Período: {start[:10]} a {end[:10]} · Jornada {schedule['start_time']} às {schedule['end_time']} · Intervalo {schedule['interval_minutes']} min</div></div>
<div class="summary">
<div class="box"><div class="muted">Trabalhadas</div><div class="value">{_fmt_minutes_html(summary['worked_minutes'])}</div></div>
<div class="box"><div class="muted">Horas extras</div><div class="value">{_fmt_minutes_html(summary['extra_minutes'])}</div></div>
<div class="box"><div class="muted">Horas negativas</div><div class="value">{_fmt_minutes_html(summary['negative_minutes'])}</div></div>
<div class="box"><div class="muted">Saldo BH</div><div class="value">{_fmt_minutes_html(summary['balance_minutes'], True)}</div></div>
</div>
<div class="rules">Tolerâncias: atraso somente quando ultrapassar 15 minutos e hora extra somente quando ultrapassar 10 minutos. Ao ultrapassar o limite, o período inteiro é computado.</div>
<table><thead><tr><th>Data</th><th>Entrada</th><th>Início int.</th><th>Fim int.</th><th>Saída</th><th>Trabalhado</th><th>Saldo BH</th><th>Situação</th></tr></thead><tbody>{rows_html}</tbody></table>
<div class="signatures"><div class="sig">Assinatura do funcionário</div><div class="sig">Responsável / Empresa</div></div>
<p class="muted" style="margin-top:40px">Gerado em {generated}.</p>
</body></html>"""


@api_router.get("/time-sheet")
async def my_time_sheet(start: str, end: str, user=Depends(get_current_user)):
    return await _build_timesheet(user["id"], start, end)


# ---------- Admin endpoints ----------
@api_router.get("/admin/users", response_model=List[UserOut])
async def admin_list_users(_admin=Depends(require_admin)):
    docs = await db.users.find({}, {"_id": 0, "password_hash": 0}).sort("created_at", 1).to_list(2000)
    return [UserOut(id=d["id"], email=d["email"], name=d["name"], role=d.get("role", "user")) for d in docs]


@api_router.put("/admin/users/{user_id}", response_model=UserOut)
async def admin_update_user(user_id: str, data: AdminUpdateUser, admin=Depends(require_admin)):
    user = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    email = data.email.lower()
    conflict = await db.users.find_one({"email": email, "id": {"$ne": user_id}})
    if conflict:
        raise HTTPException(status_code=400, detail="E-mail já cadastrado")
    if user_id == admin["id"] and data.role != "admin":
        raise HTTPException(status_code=400, detail="Você não pode remover sua própria permissão de administrador")
    await db.users.update_one({"id": user_id}, {"$set": {"name": data.name.strip(), "email": email, "role": data.role}})
    return UserOut(id=user_id, email=email, name=data.name.strip(), role=data.role)


@api_router.post("/admin/users", response_model=UserOut)
async def admin_create_user(data: AdminCreateUser, _admin=Depends(require_admin)):
    if data.role not in ("user", "admin"):
        raise HTTPException(status_code=400, detail="Papel inválido")
    existing = await db.users.find_one({"email": data.email.lower()})
    if existing:
        raise HTTPException(status_code=400, detail="Email já cadastrado")
    user_id = str(uuid.uuid4())
    await db.users.insert_one({
        "id": user_id,
        "email": data.email.lower(),
        "name": data.name,
        "password_hash": hash_password(data.password),
        "role": data.role,
        "created_at": datetime.now(timezone.utc).isoformat(),
    })
    await db.schedules.insert_one({
        "user_id": user_id,
        "start_time": "09:00",
        "interval_minutes": 60,
        "end_time": "17:20",
    })
    return UserOut(id=user_id, email=data.email.lower(), name=data.name, role=data.role)


@api_router.delete("/admin/users/{user_id}")
async def admin_delete_user(user_id: str, admin=Depends(require_admin)):
    if user_id == admin["id"]:
        raise HTTPException(status_code=400, detail="Não é possível excluir a si mesmo")
    res = await db.users.delete_one({"id": user_id})
    if res.deleted_count != 1:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    await db.schedules.delete_many({"user_id": user_id})
    await db.punches.delete_many({"user_id": user_id})
    await db.adjustments.delete_many({"user_id": user_id})
    await db.password_reset_requests.delete_many({"user_id": user_id})
    return {"ok": True}


@api_router.post("/admin/users/{user_id}/reset-password")
async def admin_reset_password(user_id: str, data: AdminResetPassword, _admin=Depends(require_admin)):
    if len(data.password) < 4:
        raise HTTPException(status_code=400, detail="Senha muito curta (mín. 4 caracteres)")
    res = await db.users.update_one({"id": user_id}, {"$set": {"password_hash": hash_password(data.password)}})
    if res.matched_count != 1:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    return {"ok": True}


@api_router.get("/admin/users/{user_id}/punches", response_model=List[PunchOut])
async def admin_list_user_punches(user_id: str, start: Optional[str] = None, end: Optional[str] = None, _admin=Depends(require_admin)):
    query = {"user_id": user_id}
    if start or end:
        ts = {}
        if start: ts["$gte"] = start
        if end: ts["$lte"] = end
        query["timestamp"] = ts
    docs = await db.punches.find(query, {"_id": 0}).sort("timestamp", 1).to_list(5000)
    return [PunchOut(
        id=d["id"], type=d["type"], photo_path=d["photo_path"],
        latitude=d["latitude"], longitude=d["longitude"],
        accuracy=d.get("accuracy"), timestamp=d["timestamp"],
        within_geofence=d.get("within_geofence"), distance_m=d.get("distance_m"),
    ) for d in docs]


@api_router.get("/admin/users/{user_id}/schedule", response_model=Schedule)
async def admin_get_user_schedule(user_id: str, _admin=Depends(require_admin)):
    s = await db.schedules.find_one({"user_id": user_id}, {"_id": 0})
    if not s:
        return Schedule()
    return Schedule(start_time=s["start_time"], interval_minutes=s["interval_minutes"], end_time=s["end_time"])


@api_router.put("/admin/users/{user_id}/schedule", response_model=Schedule)
async def admin_update_user_schedule(user_id: str, data: Schedule, _admin=Depends(require_admin)):
    user = await db.users.find_one({"id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    await db.schedules.update_one(
        {"user_id": user_id},
        {"$set": {"start_time": data.start_time, "interval_minutes": data.interval_minutes, "end_time": data.end_time}},
        upsert=True,
    )
    return data


@api_router.get("/admin/users/{user_id}/export/html", response_class=HTMLResponse)
async def admin_export_user_html(user_id: str, start: str, end: str, _admin=Depends(require_admin)):
    user = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    html = await _build_export_html(user, start, end)
    return HTMLResponse(content=html)


@api_router.get("/admin/files/{full_path:path}")
async def admin_get_file(full_path: str, _admin=Depends(require_admin)):
    try:
        content, ct = await run_in_threadpool(get_object, full_path)
    except requests.HTTPError:
        raise HTTPException(status_code=404, detail="Arquivo não encontrado")
    return Response(content=content, media_type=ct)


@api_router.get("/admin/users/{user_id}/time-sheet")
async def admin_user_time_sheet(user_id: str, start: str, end: str, _admin=Depends(require_admin)):
    return await _build_timesheet(user_id, start, end)


@api_router.post("/admin/users/{user_id}/punches/manual", response_model=PunchOut)
async def admin_manual_punch(user_id: str, data: ManualPunchCreate, _admin=Depends(require_admin)):
    user = await db.users.find_one({"id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    try:
        local_dt = datetime.fromisoformat(f"{data.date}T{data.time}:00").replace(tzinfo=timezone(BRT_OFFSET))
    except ValueError:
        raise HTTPException(status_code=400, detail="Data ou horário inválido")
    utc_dt = local_dt.astimezone(timezone.utc)
    punch_id = str(uuid.uuid4())
    doc = {
        "id": punch_id, "user_id": user_id, "type": data.type,
        "photo_path": "", "latitude": 0.0, "longitude": 0.0, "accuracy": None,
        "timestamp": utc_dt.isoformat(), "within_geofence": None, "distance_m": None,
        "source": "manual", "created_by": _admin["id"],
    }
    await db.punches.insert_one(doc)
    return PunchOut(id=punch_id, type=data.type, photo_path="", latitude=0.0, longitude=0.0,
                    accuracy=None, timestamp=utc_dt.isoformat(), within_geofence=None, distance_m=None)


@api_router.put("/admin/users/{user_id}/punches/{punch_id}", response_model=PunchOut)
async def admin_edit_punch(user_id: str, punch_id: str, data: ManualPunchCreate, _admin=Depends(require_admin)):
    try:
        local_dt = datetime.fromisoformat(f"{data.date}T{data.time}:00").replace(tzinfo=timezone(BRT_OFFSET))
    except ValueError:
        raise HTTPException(status_code=400, detail="Data ou horário inválido")
    utc_dt = local_dt.astimezone(timezone.utc)
    res = await db.punches.update_one({"id": punch_id, "user_id": user_id}, {"$set": {
        "type": data.type, "timestamp": utc_dt.isoformat(), "source": "manual_edit", "edited_by": _admin["id"]
    }})
    if res.matched_count != 1:
        raise HTTPException(status_code=404, detail="Marcação não encontrada")
    d = await db.punches.find_one({"id": punch_id}, {"_id": 0})
    return PunchOut(id=d["id"], type=d["type"], photo_path=d.get("photo_path", ""), latitude=d.get("latitude", 0.0),
                    longitude=d.get("longitude", 0.0), accuracy=d.get("accuracy"), timestamp=d["timestamp"],
                    within_geofence=d.get("within_geofence"), distance_m=d.get("distance_m"))


@api_router.delete("/admin/users/{user_id}/punches/{punch_id}")
async def admin_delete_punch(user_id: str, punch_id: str, _admin=Depends(require_admin)):
    res = await db.punches.delete_one({"id": punch_id, "user_id": user_id})
    if res.deleted_count != 1:
        raise HTTPException(status_code=404, detail="Marcação não encontrada")
    return {"ok": True}


@api_router.get("/admin/users/{user_id}/adjustments")
async def admin_list_adjustments(user_id: str, start: Optional[str] = None, end: Optional[str] = None, _admin=Depends(require_admin)):
    q: dict = {"user_id": user_id}
    if start or end:
        dq = {}
        if start: dq["$gte"] = start[:10]
        if end: dq["$lte"] = end[:10]
        q["date"] = dq
    return await db.adjustments.find(q, {"_id": 0}).sort("date", -1).to_list(5000)


@api_router.post("/admin/users/{user_id}/adjustments")
async def admin_create_adjustment(user_id: str, data: AdjustmentCreate, _admin=Depends(require_admin)):
    if not await db.users.find_one({"id": user_id}):
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    try:
        date.fromisoformat(data.date)
    except ValueError:
        raise HTTPException(status_code=400, detail="Data inválida")
    if data.kind == "abono_horas" and data.minutes < 0:
        raise HTTPException(status_code=400, detail="Horas abonadas não podem ser negativas")
    doc = {
        "id": str(uuid.uuid4()), "user_id": user_id, "date": data.date, "kind": data.kind,
        "minutes": int(data.minutes), "note": (data.note or "").strip() or None,
        "created_at": datetime.now(timezone.utc).isoformat(), "created_by": _admin["id"],
    }
    await db.adjustments.insert_one(doc)
    return {k: v for k, v in doc.items() if k != "created_by"}


@api_router.delete("/admin/users/{user_id}/adjustments/{adjustment_id}")
async def admin_delete_adjustment(user_id: str, adjustment_id: str, _admin=Depends(require_admin)):
    res = await db.adjustments.delete_one({"id": adjustment_id, "user_id": user_id})
    if res.deleted_count != 1:
        raise HTTPException(status_code=404, detail="Abono/ajuste não encontrado")
    return {"ok": True}


@api_router.get("/admin/password-reset-requests")
async def admin_password_reset_requests(_admin=Depends(require_admin)):
    return await db.password_reset_requests.find({"status": "pending"}, {"_id": 0}).sort("created_at", -1).to_list(200)


@api_router.post("/admin/password-reset-requests/{request_id}/complete")
async def admin_complete_password_reset_request(request_id: str, _admin=Depends(require_admin)):
    await db.password_reset_requests.update_one({"id": request_id}, {"$set": {"status": "completed", "completed_at": datetime.now(timezone.utc).isoformat()}})
    return {"ok": True}


@api_router.get("/admin/work-location", response_model=WorkLocation)
async def admin_get_work_location(_admin=Depends(require_admin)):
    doc = await db.app_settings.find_one({"key": "work_location"}, {"_id": 0})
    if not doc:
        return WorkLocation()
    return WorkLocation(
        latitude=doc.get("latitude"), longitude=doc.get("longitude"),
        radius_m=int(doc.get("radius_m", 200)), address=doc.get("address"),
        enabled=bool(doc.get("enabled", False)),
    )


@api_router.put("/admin/work-location", response_model=WorkLocation)
async def admin_update_work_location(data: WorkLocation, _admin=Depends(require_admin)):
    await db.app_settings.update_one(
        {"key": "work_location"},
        {"$set": {
            "key": "work_location",
            "latitude": data.latitude,
            "longitude": data.longitude,
            "radius_m": int(data.radius_m or 200),
            "address": data.address,
            "enabled": bool(data.enabled),
        }},
        upsert=True,
    )
    return data


@api_router.get("/work-location")
async def get_work_location_public(_user=Depends(get_current_user)):
    """Any logged-in user can read the geofence so the app can preview it."""
    doc = await db.app_settings.find_one({"key": "work_location"}, {"_id": 0})
    if not doc:
        return {"enabled": False}
    return {
        "enabled": bool(doc.get("enabled", False)),
        "latitude": doc.get("latitude"),
        "longitude": doc.get("longitude"),
        "radius_m": int(doc.get("radius_m", 200)),
        "address": doc.get("address"),
    }


@api_router.get("/admin/dashboard")
async def admin_dashboard(start: str, end: str, grace_min: int = 15, _admin=Depends(require_admin)):
    """
    Returns per-user weekly/period summary + late alerts.
    Interprets times in BRT (America/Sao_Paulo, fixed UTC-3).
    """
    users = await db.users.find({}, {"_id": 0, "password_hash": 0}).to_list(2000)
    schedules_list = await db.schedules.find({}, {"_id": 0}).to_list(5000)
    schedule_by_user = {s["user_id"]: s for s in schedules_list}
    punches = await db.punches.find(
        {"timestamp": {"$gte": start, "$lte": end}}, {"_id": 0}
    ).sort("timestamp", 1).to_list(20000)

    # Group punches by user_id + local BRT date
    per_user_days: dict[str, dict[str, list[dict]]] = {}
    for p in punches:
        local_dt = to_brt(p["timestamp"])
        date_key = local_dt.date().isoformat()
        per_user_days.setdefault(p["user_id"], {}).setdefault(date_key, []).append(p)

    # Determine active weekdays in the period (Mon-Fri considered work days)
    start_dt = to_brt(start).date()
    end_dt = to_brt(end).date()
    workdays: list[str] = []
    d = start_dt
    while d <= end_dt:
        if d.weekday() < 5:  # Mon-Fri
            workdays.append(d.isoformat())
        d += timedelta(days=1)

    summary = []
    alerts = []
    now_local = datetime.now(timezone.utc).astimezone(timezone(BRT_OFFSET))
    today_iso = now_local.date().isoformat()

    for u in users:
        uid = u["id"]
        sch = schedule_by_user.get(uid, {"start_time": "09:00", "interval_minutes": 60, "end_time": "17:20"})
        st_hm = parse_hhmm(sch["start_time"]) or (9, 0)
        interval = int(sch.get("interval_minutes", 60))
        days = per_user_days.get(uid, {})

        worked_ms = 0
        days_worked = 0
        late_count = 0
        missing_days = 0

        for wd in workdays:
            day_punches = days.get(wd, [])
            entrada = next((p for p in day_punches if p["type"] == "entrada"), None)
            saida = next((p for p in day_punches if p["type"] == "saida"), None)
            inicio_int = next((p for p in day_punches if p["type"] == "inicio_intervalo"), None)
            fim_int = next((p for p in day_punches if p["type"] == "fim_intervalo"), None)

            # Late detection: only for past days OR today after start_time+grace
            scheduled_start_local = datetime.combine(
                datetime.fromisoformat(wd).date(),
                datetime.min.time().replace(hour=st_hm[0], minute=st_hm[1]),
                tzinfo=timezone(BRT_OFFSET),
            )
            grace_dt = scheduled_start_local + timedelta(minutes=grace_min)

            if entrada:
                days_worked += 1
                entrada_local = to_brt(entrada["timestamp"])
                if entrada_local > grace_dt:
                    minutes_late = int((entrada_local - scheduled_start_local).total_seconds() // 60)
                    late_count += 1
                    alerts.append({
                        "user_id": uid,
                        "user_name": u["name"],
                        "date": wd,
                        "scheduled": sch["start_time"],
                        "actual": entrada_local.strftime("%H:%M"),
                        "minutes_late": minutes_late,
                        "kind": "late",
                    })

                if saida:
                    ms = (to_brt(saida["timestamp"]) - entrada_local).total_seconds() * 1000
                    if inicio_int and fim_int:
                        ms -= (to_brt(fim_int["timestamp"]) - to_brt(inicio_int["timestamp"])).total_seconds() * 1000
                    if ms > 0:
                        worked_ms += ms
            else:
                # Missing entrada: only alert if the day is in the past, or today past grace
                is_past = wd < today_iso
                is_today_past_grace = (wd == today_iso and now_local > grace_dt)
                if is_past or is_today_past_grace:
                    missing_days += 1
                    alerts.append({
                        "user_id": uid,
                        "user_name": u["name"],
                        "date": wd,
                        "scheduled": sch["start_time"],
                        "actual": None,
                        "minutes_late": None,
                        "kind": "missing",
                    })

        hours = worked_ms / 3600000.0
        summary.append({
            "user_id": uid,
            "user_name": u["name"],
            "user_email": u["email"],
            "role": u.get("role", "user"),
            "hours_worked": round(hours, 2),
            "days_worked": days_worked,
            "days_missing": missing_days,
            "late_count": late_count,
            "schedule": {
                "start_time": sch["start_time"],
                "interval_minutes": interval,
                "end_time": sch["end_time"],
            },
        })

    # Sort alerts: most recent date, then latest minutes_late
    alerts.sort(key=lambda a: (a["date"], -(a.get("minutes_late") or 0)), reverse=True)
    summary.sort(key=lambda s: (-s["late_count"] - s["days_missing"], s["user_name"]))

    return {
        "period": {"start": start, "end": end},
        "workdays": workdays,
        "summary": summary,
        "alerts": alerts[:50],
        "totals": {
            "users": len(users),
            "hours": round(sum(s["hours_worked"] for s in summary), 2),
            "late_events": sum(s["late_count"] for s in summary),
            "missing_events": sum(s["days_missing"] for s in summary),
        },
    }


# Include the router
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)


@app.on_event("startup")
async def startup():
    try:
        init_storage()
        logger.info("Storage initialized")
    except Exception as e:
        logger.error(f"Storage init failed: {e}")

    # Unique index on email
    try:
        await db.users.create_index("email", unique=True)
    except Exception as e:
        logger.warning(f"Index create warning: {e}")

    # Idempotent admin seeding
    admin_email = (os.environ.get("ADMIN_EMAIL") or "").strip().lower()
    admin_password = os.environ.get("ADMIN_PASSWORD") or ""
    admin_name = os.environ.get("ADMIN_NAME") or "Admin"
    if admin_email and admin_password:
        existing = await db.users.find_one({"email": admin_email})
        if not existing:
            uid = str(uuid.uuid4())
            await db.users.insert_one({
                "id": uid,
                "email": admin_email,
                "name": admin_name,
                "password_hash": hash_password(admin_password),
                "role": "admin",
                "created_at": datetime.now(timezone.utc).isoformat(),
            })
            await db.schedules.insert_one({
                "user_id": uid,
                "start_time": "09:00",
                "interval_minutes": 60,
                "end_time": "17:20",
            })
            logger.info(f"Admin seeded: {admin_email}")
        elif existing.get("role") != "admin":
            await db.users.update_one({"email": admin_email}, {"$set": {"role": "admin"}})
            logger.info(f"Existing user promoted to admin: {admin_email}")
        else:
            logger.info(f"Admin already present: {admin_email}")


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
